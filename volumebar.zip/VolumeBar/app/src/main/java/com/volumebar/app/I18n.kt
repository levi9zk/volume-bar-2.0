package com.volumebar.app

import android.content.Context

/** Textos do app em Português e English. */
object I18n {
    var lang: String = "pt"

    fun load(context: Context) {
        lang = Prefs.of(context).getString(Prefs.KEY_LANG, "pt") ?: "pt"
    }

    fun t(key: String): String {
        val table = if (lang == "en") en else pt
        return table[key] ?: pt[key] ?: key
    }

    private val pt: Map<String, String> = mapOf(
        "app_name" to "Volume Bar",
        "tab_home" to "Início",
        "tab_look" to "Aparência",
        "tab_settings" to "Config.",
        "tab_about" to "Sobre",
        "settings_title" to "Configurações",
        "about_title" to "Sobre",

        "power_on" to "Barra ligada",
        "power_on_sub" to "Ela substitui o painel de volume do sistema",
        "power_off" to "Barra desligada",
        "power_off_sub" to "O painel original do Android volta a aparecer",
        "perm_title" to "Permissões",
        "perm_ok" to "Serviço de acessibilidade ativo",
        "perm_missing" to "Toque para ativar o serviço de acessibilidade",
        "keep_title" to "Manter a barra funcionando",
        "keep_ok" to "Bateria sem restrição",
        "keep_missing" to "Toque para tirar a restrição de bateria",
        "hide_title" to "Esconder em apps",
        "hide_none" to "Nenhum app escolhido",
        "hide_hint" to "Nesses apps o Android cuida do volume e a barra não aparece.",
        "hide_dialog_title" to "Esconder a barra em…",
        "ok" to "OK",
        "cancel" to "Cancelar",

        "look_models" to "Modelos",
        "var_both" to "As duas",
        "var_thin" to "Só linha",
        "var_pill" to "Só barra",
        "look_place" to "Lado e posição",
        "side_left" to "Esquerda",
        "side_right" to "Direita",
        "size" to "Tamanho",
        "pos" to "Posição na tela",
        "pos_unit" to "do topo",
        "look_thin" to "Linha fina",
        "thin_color" to "Cor da linha",
        "thin_width" to "Espessura",
        "look_pill" to "Barra grande",
        "pill_bg" to "Cor do fundo",
        "pill_opacity" to "Opacidade do fundo",
        "pill_fill" to "Cor do preenchimento",
        "look_time" to "Tempo",
        "time" to "Tempo na tela",
        "reset" to "Restaurar padrão",

        "lang_title" to "Idioma",
        "lang_pt" to "Português",
        "lang_en" to "English",
        "credits" to "Créditos",
        "credits_sub" to "Siga e acompanhe as novidades",
        "open_error" to "Não consegui abrir o link",

        "version" to "Versão %s",
        "whatsnew_section" to "Novidades",
        "whatsnew" to "O que há de novo",
        "whatsnew_sub" to "Mudanças na versão",
        "help_section" to "Ajuda",
        "help" to "Como usar",
        "help_sub" to "Dicas e solução de problemas",
        "changelog" to "Versão 1.1.0\n" +
            "• Nova interface com abas: Início, Aparência, Config. e Sobre.\n" +
            "• Escolha entre a linha fina, a barra grande ou as duas.\n" +
            "• Troque as cores da linha, do fundo (o azul escuro) e do preenchimento da barra grande.\n" +
            "• Ajuste lado, tamanho, posição, espessura, opacidade e tempo na tela, com prévia ao vivo.\n" +
            "• A barra some em apps escolhidos (o Instagram já vem marcado).\n" +
            "• Idioma (Português e English) e créditos.\n" +
            "• Chave pra ligar e desligar a barra sem desativar o serviço.\n\n" +
            "Versão 1.0\n" +
            "• Primeira versão: linha fina com animação, barra grande ao arrastar, " +
            "repetição ao segurar o botão e toque fora pra fechar.",
        "help_text" to "Como usar\n\n" +
            "• Aperte os botões de volume: a linha aparece e fica na tela pelo tempo que você escolher.\n" +
            "• Segure o botão: o volume sobe ou desce sozinho.\n" +
            "• Encoste na linha e arraste: ela vira a barra grande (se as duas versões estiverem ligadas).\n" +
            "• Toque em qualquer lugar da tela: a barra some.\n\n" +
            "Se a barra não aparecer\n\n" +
            "• Confira em Início se o serviço de acessibilidade está ativo.\n" +
            "• Tire a restrição de bateria do app.\n" +
            "• Nos apps de \"Esconder em apps\" a barra não aparece de propósito."
    )

    private val en: Map<String, String> = mapOf(
        "app_name" to "Volume Bar",
        "tab_home" to "Home",
        "tab_look" to "Appearance",
        "tab_settings" to "Settings",
        "tab_about" to "About",
        "settings_title" to "Settings",
        "about_title" to "About",

        "power_on" to "Bar on",
        "power_on_sub" to "It replaces the system volume panel",
        "power_off" to "Bar off",
        "power_off_sub" to "The original Android panel is back",
        "perm_title" to "Permissions",
        "perm_ok" to "Accessibility service is on",
        "perm_missing" to "Tap to turn on the accessibility service",
        "keep_title" to "Keep the bar running",
        "keep_ok" to "Battery unrestricted",
        "keep_missing" to "Tap to remove the battery restriction",
        "hide_title" to "Hide in apps",
        "hide_none" to "No apps chosen",
        "hide_hint" to "In these apps Android handles the volume and the bar does not show.",
        "hide_dialog_title" to "Hide the bar in…",
        "ok" to "OK",
        "cancel" to "Cancel",

        "look_models" to "Styles",
        "var_both" to "Both",
        "var_thin" to "Line only",
        "var_pill" to "Big bar",
        "look_place" to "Side and position",
        "side_left" to "Left",
        "side_right" to "Right",
        "size" to "Size",
        "pos" to "Position on screen",
        "pos_unit" to "from the top",
        "look_thin" to "Thin line",
        "thin_color" to "Line color",
        "thin_width" to "Thickness",
        "look_pill" to "Big bar",
        "pill_bg" to "Background color",
        "pill_opacity" to "Background opacity",
        "pill_fill" to "Fill color",
        "look_time" to "Timing",
        "time" to "Time on screen",
        "reset" to "Restore defaults",

        "lang_title" to "Language",
        "lang_pt" to "Português",
        "lang_en" to "English",
        "credits" to "Credits",
        "credits_sub" to "Follow for news and updates",
        "open_error" to "Could not open the link",

        "version" to "Version %s",
        "whatsnew_section" to "Updates",
        "whatsnew" to "What's new",
        "whatsnew_sub" to "Changes in version",
        "help_section" to "Help",
        "help" to "How to use",
        "help_sub" to "Tips and troubleshooting",
        "changelog" to "Version 1.1.0\n" +
            "• New tabbed interface: Home, Appearance, Settings and About.\n" +
            "• Pick the thin line, the big bar or both.\n" +
            "• Change the colors of the line, the background (the dark blue) and the fill of the big bar.\n" +
            "• Adjust side, size, position, thickness, opacity and time on screen, with a live preview.\n" +
            "• The bar hides in chosen apps (Instagram is already checked).\n" +
            "• Language (Português and English) and credits.\n" +
            "• Switch to turn the bar on and off without disabling the service.\n\n" +
            "Version 1.0\n" +
            "• First version: animated thin line, big bar when dragging, " +
            "repeat while holding the button and tap outside to close.",
        "help_text" to "How to use\n\n" +
            "• Press the volume buttons: the line shows up and stays for the time you choose.\n" +
            "• Hold the button: the volume keeps going up or down.\n" +
            "• Touch the line and drag: it becomes the big bar (if both styles are on).\n" +
            "• Tap anywhere on the screen: the bar hides.\n\n" +
            "If the bar does not show\n\n" +
            "• Check on Home that the accessibility service is on.\n" +
            "• Remove the app's battery restriction.\n" +
            "• In the \"Hide in apps\" list the bar stays hidden on purpose."
    )
}
