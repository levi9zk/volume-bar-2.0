package com.volumebar.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** Ícones simples desenhados na mão (sem precisar de arquivos de imagem). */
class IconView(context: Context, private val kind: Int, var color: Int = Color.WHITE) :
    View(context) {

    companion object {
        const val POWER = 0
        const val CHECK = 1
        const val BATTERY = 2
        const val GRID = 3
        const val GLOBE = 4
        const val STAR = 5
        const val CHEVRON = 6
        const val PHONE = 7
        const val PALETTE = 8
        const val SLIDERS = 9
        const val INFO = 10
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val r = RectF()

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height).toFloat()
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        fun x(f: Float): Float = ox + f * s
        fun y(f: Float): Float = oy + f * s

        p.color = color
        p.strokeWidth = s * 0.09f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND

        when (kind) {
            POWER -> {
                p.style = Paint.Style.STROKE
                r.set(x(0.2f), y(0.22f), x(0.8f), y(0.82f))
                canvas.drawArc(r, -60f, 300f, false, p)
                canvas.drawLine(x(0.5f), y(0.1f), x(0.5f), y(0.5f), p)
            }
            CHECK -> {
                p.style = Paint.Style.STROKE
                canvas.drawCircle(x(0.5f), y(0.5f), s * 0.34f, p)
                path.reset()
                path.moveTo(x(0.34f), y(0.52f))
                path.lineTo(x(0.45f), y(0.63f))
                path.lineTo(x(0.67f), y(0.4f))
                canvas.drawPath(path, p)
            }
            BATTERY -> {
                p.style = Paint.Style.STROKE
                r.set(x(0.3f), y(0.2f), x(0.7f), y(0.86f))
                canvas.drawRoundRect(r, s * 0.07f, s * 0.07f, p)
                p.style = Paint.Style.FILL
                r.set(x(0.42f), y(0.11f), x(0.58f), y(0.2f))
                canvas.drawRect(r, p)
                path.reset()
                path.moveTo(x(0.53f), y(0.3f))
                path.lineTo(x(0.4f), y(0.56f))
                path.lineTo(x(0.49f), y(0.56f))
                path.lineTo(x(0.46f), y(0.76f))
                path.lineTo(x(0.6f), y(0.48f))
                path.lineTo(x(0.51f), y(0.48f))
                path.close()
                canvas.drawPath(path, p)
            }
            GRID -> {
                p.style = Paint.Style.FILL
                val q = s * 0.06f
                r.set(x(0.2f), y(0.2f), x(0.46f), y(0.46f))
                canvas.drawRoundRect(r, q, q, p)
                r.set(x(0.54f), y(0.2f), x(0.8f), y(0.46f))
                canvas.drawRoundRect(r, q, q, p)
                r.set(x(0.2f), y(0.54f), x(0.46f), y(0.8f))
                canvas.drawRoundRect(r, q, q, p)
                r.set(x(0.54f), y(0.54f), x(0.8f), y(0.8f))
                canvas.drawRoundRect(r, q, q, p)
            }
            GLOBE -> {
                p.style = Paint.Style.STROKE
                canvas.drawCircle(x(0.5f), y(0.5f), s * 0.33f, p)
                r.set(x(0.38f), y(0.17f), x(0.62f), y(0.83f))
                canvas.drawOval(r, p)
                canvas.drawLine(x(0.17f), y(0.5f), x(0.83f), y(0.5f), p)
            }
            STAR -> {
                p.style = Paint.Style.FILL
                path.reset()
                for (i in 0 until 10) {
                    val rad = if (i % 2 == 0) 0.42f * s else 0.18f * s
                    val ang = Math.toRadians((-90 + i * 36).toDouble())
                    val px = x(0.5f) + (rad * cos(ang)).toFloat()
                    val py = y(0.52f) + (rad * sin(ang)).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                canvas.drawPath(path, p)
            }
            CHEVRON -> {
                p.style = Paint.Style.STROKE
                path.reset()
                path.moveTo(x(0.38f), y(0.25f))
                path.lineTo(x(0.62f), y(0.5f))
                path.lineTo(x(0.38f), y(0.75f))
                canvas.drawPath(path, p)
            }
            PHONE -> {
                p.style = Paint.Style.STROKE
                r.set(x(0.3f), y(0.14f), x(0.7f), y(0.86f))
                canvas.drawRoundRect(r, s * 0.1f, s * 0.1f, p)
                canvas.drawLine(x(0.44f), y(0.24f), x(0.56f), y(0.24f), p)
            }
            PALETTE -> {
                p.style = Paint.Style.STROKE
                canvas.drawCircle(x(0.5f), y(0.5f), s * 0.36f, p)
                p.style = Paint.Style.FILL
                canvas.drawCircle(x(0.37f), y(0.42f), s * 0.05f, p)
                canvas.drawCircle(x(0.55f), y(0.34f), s * 0.05f, p)
                canvas.drawCircle(x(0.66f), y(0.52f), s * 0.05f, p)
                canvas.drawCircle(x(0.45f), y(0.64f), s * 0.05f, p)
            }
            SLIDERS -> {
                p.style = Paint.Style.STROKE
                canvas.drawLine(x(0.2f), y(0.3f), x(0.8f), y(0.3f), p)
                canvas.drawLine(x(0.2f), y(0.5f), x(0.8f), y(0.5f), p)
                canvas.drawLine(x(0.2f), y(0.7f), x(0.8f), y(0.7f), p)
                p.style = Paint.Style.FILL
                canvas.drawCircle(x(0.36f), y(0.3f), s * 0.08f, p)
                canvas.drawCircle(x(0.66f), y(0.5f), s * 0.08f, p)
                canvas.drawCircle(x(0.46f), y(0.7f), s * 0.08f, p)
            }
            INFO -> {
                p.style = Paint.Style.STROKE
                canvas.drawCircle(x(0.5f), y(0.5f), s * 0.36f, p)
                canvas.drawLine(x(0.5f), y(0.48f), x(0.5f), y(0.68f), p)
                p.style = Paint.Style.FILL
                canvas.drawCircle(x(0.5f), y(0.35f), s * 0.05f, p)
            }
        }
    }
}
