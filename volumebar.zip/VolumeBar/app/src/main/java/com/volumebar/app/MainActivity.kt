package com.volumebar.app

import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class NavItem(val pill: FrameLayout, val icon: IconView, val label: TextView)

    private var tab = 0
    private lateinit var container: FrameLayout
    private val nav = ArrayList<NavItem>()

    private fun t(key: String): String = I18n.t(key)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        I18n.load(this)
        window.statusBarColor = Theme.bg
        window.navigationBarColor = Theme.bg
        tab = savedInstanceState?.getInt("tab") ?: 0
        buildShell()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    override fun onResume() {
        super.onResume()
        showTab(tab) // refaz a página, pra os status (permissões, bateria) ficarem atualizados
    }

    // ================= estrutura: conteúdo + barra de abas =================

    private fun buildShell() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Theme.bg)

        container = FrameLayout(this)
        root.addView(container, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val navParams = LinearLayout.LayoutParams(MATCH, WRAP)
        navParams.setMargins(dp(14), dp(6), dp(14), dp(12))
        root.addView(buildNav(), navParams)

        setContentView(root)
    }

    private fun buildNav(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.background = rounded(Theme.nav, dp(30).toFloat())
        bar.setPadding(dp(6), dp(10), dp(6), dp(8))

        nav.clear()
        addNavItem(bar, IconView.PHONE, t("tab_home"), 0)
        addNavItem(bar, IconView.PALETTE, t("tab_look"), 1)
        addNavItem(bar, IconView.SLIDERS, t("tab_settings"), 2)
        addNavItem(bar, IconView.INFO, t("tab_about"), 3)
        return bar
    }

    private fun addNavItem(bar: LinearLayout, kind: Int, name: String, index: Int) {
        val pill = FrameLayout(this)
        val icon = IconView(this, kind, Theme.dim)
        pill.addView(icon, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))

        val tv = label(name, 11f, Theme.dim, true)
        tv.gravity = Gravity.CENTER
        tv.maxLines = 1

        val item = LinearLayout(this)
        item.orientation = LinearLayout.VERTICAL
        item.gravity = Gravity.CENTER_HORIZONTAL
        item.addView(pill, LinearLayout.LayoutParams(dp(60), dp(32)))
        val tvParams = LinearLayout.LayoutParams(WRAP, WRAP)
        tvParams.topMargin = dp(4)
        item.addView(tv, tvParams)
        item.isClickable = true
        item.setOnClickListener { showTab(index) }

        bar.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        nav.add(NavItem(pill, icon, tv))
    }

    private fun paintNav() {
        for (i in nav.indices) {
            val n = nav[i]
            if (i == tab) {
                n.pill.background = rounded(Theme.accent, dp(16).toFloat())
                n.icon.color = Theme.onAccent
                n.label.setTextColor(Theme.text)
            } else {
                n.pill.background = null
                n.icon.color = Theme.dim
                n.label.setTextColor(Theme.dim)
            }
            n.icon.invalidate()
        }
    }

    private fun showTab(i: Int) {
        tab = i
        paintNav()
        container.removeAllViews()
        val page = when (i) {
            0 -> homePage()
            1 -> lookPage()
            2 -> settingsPage()
            else -> aboutPage()
        }
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(page)
        container.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun pageShell(title: String): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(22), dp(18), dp(24))
        col.addView(label(title, 32f, Theme.text, true))
        return col
    }

    // ================= aba Início =================

    private fun homePage(): LinearLayout {
        val c = Prefs.load(this)
        val col = pageShell(t("app_name"))

        val preview = PreviewView(this)
        val pvParams = LinearLayout.LayoutParams(MATCH, dp(190))
        pvParams.topMargin = dp(14)
        col.addView(preview, pvParams)

        // ligar / desligar
        val sw = styledSwitch(c.enabled) { on ->
            Prefs.putBool(this, Prefs.KEY_ENABLED, on)
            showTab(tab)
        }
        col.addView(
            row(
                iconBadge(IconView.POWER, if (c.enabled) Theme.green else Theme.red),
                if (c.enabled) t("power_on") else t("power_off"),
                if (c.enabled) t("power_on_sub") else t("power_off_sub"),
                null,
                sw
            )
        )

        // permissões (serviço de acessibilidade)
        val permOk = isServiceEnabled()
        col.addView(
            row(
                iconBadge(IconView.CHECK, if (permOk) Theme.green else Theme.orange),
                t("perm_title"),
                if (permOk) t("perm_ok") else t("perm_missing"),
                { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                null
            )
        )

        // bateria
        val batteryOk = isBatteryUnrestricted()
        col.addView(
            row(
                iconBadge(IconView.BATTERY, if (batteryOk) Theme.green else Theme.orange),
                t("keep_title"),
                if (batteryOk) t("keep_ok") else t("keep_missing"),
                { openBatterySettings(batteryOk) },
                null
            )
        )

        // esconder em apps
        val names = c.hideApps.map { appLabel(it) }.sorted()
        val hideSub = when {
            names.isEmpty() -> t("hide_none")
            names.size <= 2 -> names.joinToString(", ")
            else -> names.take(2).joinToString(", ") + " +" + (names.size - 2)
        }
        col.addView(
            row(
                iconBadge(IconView.GRID, Theme.indigo),
                t("hide_title"),
                hideSub,
                { showHideAppsDialog() },
                null
            )
        )
        val hint = label(t("hide_hint"), 12f, Theme.dim)
        hint.setPadding(dp(6), dp(8), dp(6), 0)
        col.addView(hint)

        return col
    }

    private fun isServiceEnabled(): Boolean {
        val enabledList = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        val full = "$packageName/${VolumeService::class.java.name}"
        val short = "$packageName/.VolumeService"
        return enabledList.split(':').any {
            it.equals(full, ignoreCase = true) || it.equals(short, ignoreCase = true)
        }
    }

    private fun isBatteryUnrestricted(): Boolean {
        val pm = getSystemService(PowerManager::class.java)
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun openBatterySettings(alreadyOk: Boolean) {
        try {
            if (alreadyOk) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } else {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                Toast.makeText(this, t("open_error"), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun appLabel(pkg: String): String {
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            if (pkg == "com.instagram.android") "Instagram" else pkg
        }
    }

    private fun showHideAppsDialog() {
        val pm = packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps: List<Pair<String, String>> = pm.queryIntentActivities(launch, 0)
            .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.first != packageName }
            .distinctBy { it.first }

        val selected = Prefs.load(this).hideApps
        // apps escolhidos que não aparecem na lista (ex.: não instalados) continuam guardados
        val keep = selected.filter { pkg -> apps.none { it.first == pkg } }

        val sorted = apps.sortedWith(
            compareByDescending<Pair<String, String>> { selected.contains(it.first) }
                .thenBy { it.second.lowercase() }
        )
        val labels: Array<CharSequence> = Array(sorted.size) { sorted[it].second }
        val checked = BooleanArray(sorted.size) { selected.contains(sorted[it].first) }

        AlertDialog.Builder(this, DIALOG_THEME)
            .setTitle(t("hide_dialog_title"))
            .setMultiChoiceItems(
                labels,
                checked,
                DialogInterface.OnMultiChoiceClickListener { _, which, isChecked ->
                    checked[which] = isChecked
                }
            )
            .setPositiveButton(t("ok")) { _, _ ->
                val result = HashSet<String>(keep)
                for (i in sorted.indices) {
                    if (checked[i]) result.add(sorted[i].first)
                }
                Prefs.putSet(this, Prefs.KEY_HIDE_APPS, result)
                showTab(tab)
            }
            .setNegativeButton(t("cancel"), null)
            .show()
    }

    // ================= aba Aparência =================

    private fun lookPage(): LinearLayout {
        var cfg = Prefs.load(this)
        val col = pageShell(t("tab_look"))

        val preview = PreviewView(this)
        val pvParams = LinearLayout.LayoutParams(MATCH, dp(190))
        pvParams.topMargin = dp(14)
        col.addView(preview, pvParams)

        fun refresh() {
            preview.update(cfg)
        }

        // ----- modelos: as duas, só a linha ou só a barra grande -----
        col.addView(sectionTitle(t("look_models")))
        val cModels = card()
        cModels.addView(
            segmented(
                listOf(t("var_both"), t("var_thin"), t("var_pill")),
                cfg.variant
            ) { i ->
                cfg = cfg.copy(variant = i)
                Prefs.putInt(this, Prefs.KEY_VARIANT, i)
                refresh()
            }
        )
        col.addView(cModels)

        // ----- lado, tamanho e posição -----
        col.addView(sectionTitle(t("look_place")))
        val cPlace = card()
        cPlace.addView(
            segmented(
                listOf(t("side_left"), t("side_right")),
                cfg.side
            ) { i ->
                cfg = cfg.copy(side = i)
                Prefs.putInt(this, Prefs.KEY_SIDE, i)
                refresh()
            }
        )

        val sizeLbl = label(sizeText(cfg.size), 14f, Theme.dim)
        sizeLbl.setPadding(0, dp(18), 0, 0)
        cPlace.addView(sizeLbl)
        cPlace.addView(
            slider(
                Prefs.MAX_SIZE - Prefs.MIN_SIZE,
                cfg.size - Prefs.MIN_SIZE,
                { p ->
                    cfg = cfg.copy(size = Prefs.MIN_SIZE + p)
                    sizeLbl.text = sizeText(cfg.size)
                    refresh()
                },
                { p -> Prefs.putInt(this, Prefs.KEY_SIZE, Prefs.MIN_SIZE + p) }
            )
        )

        val posLbl = label(posText(cfg.pos), 14f, Theme.dim)
        posLbl.setPadding(0, dp(14), 0, 0)
        cPlace.addView(posLbl)
        cPlace.addView(
            slider(
                Prefs.MAX_POS,
                cfg.pos,
                { p ->
                    cfg = cfg.copy(pos = p)
                    posLbl.text = posText(p)
                },
                { p -> Prefs.putInt(this, Prefs.KEY_POS, p) }
            )
        )
        col.addView(cPlace)

        // ----- linha fina -----
        col.addView(sectionTitle(t("look_thin")))
        val cThin = card()
        cThin.addView(
            colorRow(t("thin_color"), cfg.thinColor) { picked ->
                cfg = cfg.copy(thinColor = picked)
                Prefs.putInt(this, Prefs.KEY_THIN_COLOR, picked)
                refresh()
            }
        )
        val thinLbl = label(thinText(cfg.thinWidth), 14f, Theme.dim)
        thinLbl.setPadding(0, dp(14), 0, 0)
        cThin.addView(thinLbl)
        cThin.addView(
            slider(
                Prefs.MAX_THIN - Prefs.MIN_THIN,
                cfg.thinWidth - Prefs.MIN_THIN,
                { p ->
                    cfg = cfg.copy(thinWidth = Prefs.MIN_THIN + p)
                    thinLbl.text = thinText(cfg.thinWidth)
                    refresh()
                },
                { p -> Prefs.putInt(this, Prefs.KEY_THIN_WIDTH, Prefs.MIN_THIN + p) }
            )
        )
        col.addView(cThin)

        // ----- barra grande -----
        col.addView(sectionTitle(t("look_pill")))
        val cPill = card()
        cPill.addView(
            colorRow(t("pill_bg"), cfg.pillBg) { picked ->
                cfg = cfg.copy(pillBg = picked)
                Prefs.putInt(this, Prefs.KEY_PILL_BG, picked)
                refresh()
            }
        )
        cPill.addView(
            colorRow(t("pill_fill"), cfg.pillFill) { picked ->
                cfg = cfg.copy(pillFill = picked)
                Prefs.putInt(this, Prefs.KEY_PILL_FILL, picked)
                refresh()
            }
        )
        val opLbl = label(opacityText(cfg.pillAlpha), 14f, Theme.dim)
        opLbl.setPadding(0, dp(14), 0, 0)
        cPill.addView(opLbl)
        cPill.addView(
            slider(
                90,
                cfg.pillAlpha - 10,
                { p ->
                    cfg = cfg.copy(pillAlpha = 10 + p)
                    opLbl.text = opacityText(cfg.pillAlpha)
                    refresh()
                },
                { p -> Prefs.putInt(this, Prefs.KEY_PILL_ALPHA, 10 + p) }
            )
        )
        col.addView(cPill)

        // ----- tempo na tela -----
        col.addView(sectionTitle(t("look_time")))
        val cTime = card()
        val timeLbl = label(timeText(cfg.showSeconds), 14f, Theme.dim)
        cTime.addView(timeLbl)
        cTime.addView(
            slider(
                Prefs.MAX_SECONDS - Prefs.MIN_SECONDS,
                cfg.showSeconds - Prefs.MIN_SECONDS,
                { p ->
                    cfg = cfg.copy(showSeconds = Prefs.MIN_SECONDS + p)
                    timeLbl.text = timeText(cfg.showSeconds)
                },
                { p -> Prefs.putInt(this, Prefs.KEY_SHOW_SECONDS, Prefs.MIN_SECONDS + p) }
            )
        )
        col.addView(cTime)

        col.addView(
            button(t("reset")) {
                Prefs.resetAppearance(this)
                showTab(tab)
            }
        )
        return col
    }

    private fun sizeText(v: Int): String = t("size") + ": " + (v * 100 / Prefs.DEF_SIZE) + "%"

    private fun posText(v: Int): String = t("pos") + ": " + v + "% " + t("pos_unit")

    private fun thinText(v: Int): String = t("thin_width") + ": " + v + " dp"

    private fun opacityText(v: Int): String = t("pill_opacity") + ": " + v + "%"

    private fun timeText(v: Int): String = t("time") + ": " + v + " s"

    // ================= aba Configurações =================

    private fun settingsPage(): LinearLayout {
        val col = pageShell(t("settings_title"))

        col.addView(sectionTitle(t("lang_title")))
        val cLang = card()
        cLang.addView(
            segmented(
                listOf(t("lang_pt"), t("lang_en")),
                if (I18n.lang == "en") 1 else 0
            ) { i ->
                Prefs.putString(this, Prefs.KEY_LANG, if (i == 1) "en" else "pt")
                recreate()
            }
        )
        col.addView(cLang)

        col.addView(sectionTitle(t("credits")))
        val sub = label(t("credits_sub"), 13f, Theme.dim)
        sub.setPadding(dp(4), 0, 0, dp(2))
        col.addView(sub)
        col.addView(
            row(
                textBadge("IG", Color.rgb(0xE1, 0x30, 0x6C)),
                "Instagram",
                "@mxrais7",
                { openUrl("https://instagram.com/mxrais7") },
                null
            )
        )
        col.addView(
            row(
                textBadge("GH", Color.rgb(0x3D, 0x44, 0x4D)),
                "GitHub",
                "levi9zk",
                { openUrl("https://github.com/levi9zk") },
                null
            )
        )
        return col
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, t("open_error"), Toast.LENGTH_SHORT).show()
        }
    }

    // ================= aba Sobre =================

    private fun versionName(): String {
        return try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
        } catch (e: Exception) {
            "?"
        }
    }

    private fun aboutPage(): LinearLayout {
        val col = pageShell(t("about_title"))
        val version = versionName()

        val head = card()
        head.gravity = Gravity.CENTER_HORIZONTAL
        head.setPadding(dp(18), dp(24), dp(18), dp(22))
        head.addView(AppMarkView(this), LinearLayout.LayoutParams(dp(96), dp(96)))
        val name = label(t("app_name"), 24f, Theme.text, true)
        name.setPadding(0, dp(14), 0, 0)
        head.addView(name)
        head.addView(label(t("version").replace("%s", version), 14f, Theme.dim))
        col.addView(head)

        col.addView(sectionTitle(t("whatsnew_section")))
        col.addView(
            row(
                iconBadge(IconView.STAR, Theme.purple),
                t("whatsnew"),
                t("whatsnew_sub") + " " + version,
                { showText(t("whatsnew"), t("changelog")) },
                null
            )
        )

        col.addView(sectionTitle(t("help_section")))
        col.addView(
            row(
                iconBadge(IconView.INFO, Theme.blue),
                t("help"),
                t("help_sub"),
                { showText(t("help"), t("help_text")) },
                null
            )
        )
        return col
    }

    private fun showText(title: String, message: String) {
        AlertDialog.Builder(this, DIALOG_THEME)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(t("ok"), null)
            .show()
    }
}
