package com.volumebar.app

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private val bgColor = Color.rgb(0x12, 0x12, 0x16)
    private val cardColor = Color.rgb(0x1E, 0x1F, 0x27)
    private val chipColor = Color.rgb(0x2A, 0x2C, 0x38)
    private val accent = Color.rgb(0x5B, 0x8C, 0xFF)
    private val textDim = Color.rgb(0xA0, 0xA4, 0xB5)
    private val good = Color.rgb(0x4C, 0xD9, 0x7B)
    private val warn = Color.rgb(0xFF, 0xB0, 0x40)

    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var statusText: TextView
    private lateinit var btnLeft: TextView
    private lateinit var btnRight: TextView
    private lateinit var sizeLabel: TextView
    private lateinit var posLabel: TextView
    private lateinit var sizeBar: SeekBar
    private lateinit var posBar: SeekBar

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = sizeSp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(cardColor, 18)
        setPadding(dp(18), dp(16), dp(18), dp(18))
        layoutParams = LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(14) }
    }

    private fun segButton(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 15f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        layoutParams = LinearLayout.LayoutParams(0, match, 1f).apply {
            setMargins(dp(3), 0, dp(3), 0)
        }
        setOnClickListener { onClick() }
    }

    private fun seekBar(
        max: Int,
        progress: Int,
        onChange: (Int) -> Unit,
        onDone: (Int) -> Unit
    ) = SeekBar(this).apply {
        this.max = max
        this.progress = progress
        progressTintList = ColorStateList.valueOf(accent)
        thumbTintList = ColorStateList.valueOf(accent)
        layoutParams = LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(6) }
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) = onChange(p)
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) = onDone(s.progress)
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor

        val prefs = Prefs.of(this)
        val side = prefs.getInt(Prefs.KEY_SIDE, Prefs.DEF_SIDE)
        val size = prefs.getInt(Prefs.KEY_SIZE, Prefs.DEF_SIZE)
            .coerceIn(Prefs.MIN_SIZE, Prefs.MAX_SIZE)
        val pos = prefs.getInt(Prefs.KEY_POS, Prefs.DEF_POS).coerceIn(0, Prefs.MAX_POS)

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(26), dp(18), dp(30))
        }

        column.addView(label("Volume Bar", 30f, Color.WHITE, bold = true))
        column.addView(
            label("Barra de volume fina, no estilo do iPhone", 14f, textDim).apply {
                setPadding(0, dp(2), 0, 0)
            }
        )

        // ----- Status do serviço -----
        val statusCard = card()
        statusText = label("", 15f, Color.WHITE, bold = true)
        statusCard.addView(statusText)
        statusCard.addView(
            Button(this).apply {
                text = "Abrir ajustes de acessibilidade"
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = rounded(accent, 12)
                layoutParams = LinearLayout.LayoutParams(match, dp(46)).apply {
                    topMargin = dp(12)
                }
                setOnClickListener {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
        )
        column.addView(statusCard)

        // ----- Aparência -----
        val look = card()
        look.addView(label("Aparência", 18f, Color.WHITE, bold = true))

        look.addView(label("Lado da tela", 14f, textDim).apply { setPadding(0, dp(14), 0, 0) })
        val segment = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(match, dp(46)).apply { topMargin = dp(8) }
        }
        btnLeft = segButton("Esquerda") { setSide(0) }
        btnRight = segButton("Direita") { setSide(1) }
        segment.addView(btnLeft)
        segment.addView(btnRight)
        look.addView(segment)
        paintSide(side)

        sizeLabel = label("", 14f, textDim).apply { setPadding(0, dp(20), 0, 0) }
        look.addView(sizeLabel)
        sizeBar = seekBar(
            Prefs.MAX_SIZE - Prefs.MIN_SIZE,
            size - Prefs.MIN_SIZE,
            onChange = { p -> showSize(Prefs.MIN_SIZE + p) },
            onDone = { p ->
                Prefs.of(this).edit().putInt(Prefs.KEY_SIZE, Prefs.MIN_SIZE + p).apply()
            }
        )
        look.addView(sizeBar)
        showSize(size)

        posLabel = label("", 14f, textDim).apply { setPadding(0, dp(16), 0, 0) }
        look.addView(posLabel)
        posBar = seekBar(
            Prefs.MAX_POS,
            pos,
            onChange = { p -> showPos(p) },
            onDone = { p -> Prefs.of(this).edit().putInt(Prefs.KEY_POS, p).apply() }
        )
        look.addView(posBar)
        showPos(pos)

        look.addView(
            Button(this).apply {
                text = "Restaurar padrão"
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = rounded(chipColor, 12)
                layoutParams = LinearLayout.LayoutParams(match, dp(44)).apply {
                    topMargin = dp(18)
                }
                setOnClickListener { resetDefaults() }
            }
        )
        column.addView(look)

        // ----- Dicas -----
        val tips = card()
        tips.addView(label("Como usar", 18f, Color.WHITE, bold = true))
        tips.addView(
            label(
                "• Aperte os botões de volume: a linha aparece e fica 7 segundos.\n" +
                    "• Segure o botão: o volume sobe ou desce sozinho.\n" +
                    "• Encoste na linha e arraste: ela vira a barra grande.\n" +
                    "• Toque em qualquer lugar da tela: a barra some.\n\n" +
                    "Com o serviço ativado, a barra aparece na hora quando você solta um controle acima.",
                14f,
                textDim
            ).apply { setPadding(0, dp(10), 0, 0); setLineSpacing(0f, 1.15f) }
        )
        column.addView(tips)

        setContentView(
            ScrollView(this).apply {
                setBackgroundColor(bgColor)
                addView(column)
            }
        )
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val enabledList = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        val full = "$packageName/${VolumeService::class.java.name}"
        val short = "$packageName/.VolumeService"
        val on = enabledList.split(':').any {
            it.equals(full, ignoreCase = true) || it.equals(short, ignoreCase = true)
        }
        if (on) {
            statusText.text = "● Serviço ativo"
            statusText.setTextColor(good)
        } else {
            statusText.text = "● Serviço desativado: ative em Acessibilidade > Volume Bar"
            statusText.setTextColor(warn)
        }
    }

    private fun setSide(s: Int) {
        Prefs.of(this).edit().putInt(Prefs.KEY_SIDE, s).apply()
        paintSide(s)
    }

    private fun paintSide(s: Int) {
        btnLeft.background = rounded(if (s == 0) accent else chipColor, 12)
        btnRight.background = rounded(if (s == 1) accent else chipColor, 12)
        btnLeft.setTextColor(if (s == 0) Color.WHITE else textDim)
        btnRight.setTextColor(if (s == 1) Color.WHITE else textDim)
    }

    private fun showSize(sizeDp: Int) {
        val pct = (sizeDp * 100f / Prefs.DEF_SIZE).toInt()
        sizeLabel.text = "Tamanho: $pct%"
    }

    private fun showPos(p: Int) {
        posLabel.text = "Posição na tela: $p% da altura, contando do topo"
    }

    private fun resetDefaults() {
        Prefs.of(this).edit()
            .putInt(Prefs.KEY_SIDE, Prefs.DEF_SIDE)
            .putInt(Prefs.KEY_SIZE, Prefs.DEF_SIZE)
            .putInt(Prefs.KEY_POS, Prefs.DEF_POS)
            .apply()
        paintSide(Prefs.DEF_SIDE)
        sizeBar.progress = Prefs.DEF_SIZE - Prefs.MIN_SIZE
        posBar.progress = Prefs.DEF_POS
        showSize(Prefs.DEF_SIZE)
        showPos(Prefs.DEF_POS)
    }
}
