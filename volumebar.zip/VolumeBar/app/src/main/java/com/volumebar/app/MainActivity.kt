package com.volumebar.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class MainActivity : Activity() {

    companion object {
        private const val ANIM_NONE = 0
        private const val ANIM_STAGGER = 1
        private const val ANIM_FROM_RIGHT = 2
        private const val ANIM_FROM_LEFT = 3
        private const val TABS = 3
    }

    private var tab = 0
    private var inSettings = false
    private var firstResume = true
    private lateinit var container: FrameLayout
    private lateinit var indicator: View
    private val navIcons = ArrayList<IconView>()
    private val navLabels = ArrayList<TextView>()
    private var navItemW = 0f

    private fun t(key: String): String = I18n.t(key)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        I18n.load(this)
        Fonts.load(this)
        window.statusBarColor = Theme.bg
        window.navigationBarColor = Theme.bg
        tab = savedInstanceState?.getInt("tab") ?: 0
        inSettings = savedInstanceState?.getBoolean("settings") ?: false
        buildShell()
        paintNav(false)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
        outState.putBoolean("settings", inSettings)
    }

    override fun onResume() {
        super.onResume()
        // refaz a página, pra os status (permissões, bateria) ficarem atualizados
        renderPage(if (firstResume) ANIM_STAGGER else ANIM_NONE)
        firstResume = false
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (inSettings) closeSettings() else super.onBackPressed()
    }

    // ================= estrutura: conteúdo + barra de abas =================

    private fun buildShell() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Theme.bg)

        container = FrameLayout(this)
        root.addView(container, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val navParams = LinearLayout.LayoutParams(MATCH, WRAP)
        navParams.setMargins(dp(14), dp(6), dp(14), dp(12))
        root.addView(buildNav(), navParams)

        setContentView(root)
    }

    private fun buildNav(): FrameLayout {
        val bar = FrameLayout(this)
        bar.background = rounded(Theme.nav, dp(32).toFloat())
        bar.setPadding(dp(8), dp(10), dp(8), dp(8))

        // indicador (pílula lavanda) que desliza de uma aba pra outra
        indicator = View(this)
        indicator.background = rounded(Theme.accent, dp(16).toFloat())
        indicator.alpha = 0f
        bar.addView(indicator, FrameLayout.LayoutParams(dp(64), dp(32), Gravity.TOP or Gravity.START))

        val items = LinearLayout(this)
        items.orientation = LinearLayout.HORIZONTAL
        bar.addView(items, FrameLayout.LayoutParams(MATCH, WRAP))

        navIcons.clear()
        navLabels.clear()
        addNavItem(items, IconView.PHONE, t("tab_home"), 0)
        addNavItem(items, IconView.PALETTE, t("tab_look"), 1)
        addNavItem(items, IconView.INFO, t("tab_about"), 2)

        bar.addOnLayoutChangeListener { v, left, _, right, _, _, _, _, _ ->
            val inner = (right - left) - v.paddingLeft - v.paddingRight
            val w = inner.toFloat() / TABS
            if (abs(w - navItemW) > 0.5f) {
                navItemW = w
                indicator.post { moveIndicator(false) }
            }
        }
        return bar
    }

    private fun addNavItem(bar: LinearLayout, kind: Int, name: String, index: Int) {
        val pill = FrameLayout(this)
        val icon = IconView(this, kind, Theme.text)
        pill.addView(icon, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))

        val tv = label(name, 11f, Theme.dim, true)
        tv.gravity = Gravity.CENTER
        tv.maxLines = 1

        val item = LinearLayout(this)
        item.orientation = LinearLayout.VERTICAL
        item.gravity = Gravity.CENTER_HORIZONTAL
        item.addView(pill, LinearLayout.LayoutParams(dp(64), dp(32)))
        val tvParams = LinearLayout.LayoutParams(WRAP, WRAP)
        tvParams.topMargin = dp(4)
        item.addView(tv, tvParams)
        item.isClickable = true
        item.setOnClickListener { selectTab(index) }
        item.pressable()

        bar.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        navIcons.add(icon)
        navLabels.add(tv)
    }

    private fun paintNav(bounce: Boolean) {
        for (i in navIcons.indices) {
            val sel = !inSettings && i == tab
            val icon = navIcons[i]
            icon.color = if (sel) Theme.onAccent else Theme.text
            icon.invalidate()
            navLabels[i].setTextColor(if (sel) Theme.text else Theme.dim)
            if (bounce && sel) {
                icon.animate().cancel()
                icon.scaleX = 0.7f
                icon.scaleY = 0.7f
                icon.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setStartDelay(0)
                    .setDuration(340)
                    .setInterpolator(OvershootInterpolator(2.5f))
                    .start()
            }
        }
    }

    private fun moveIndicator(animate: Boolean) {
        indicator.animate().cancel()
        if (inSettings) {
            // na tela de configurações nenhuma aba fica marcada
            if (animate) {
                indicator.animate().alpha(0f).setStartDelay(0).setDuration(200).start()
            } else {
                indicator.alpha = 0f
            }
            return
        }
        val target = tab * navItemW + (navItemW - dp(64)) / 2f
        if (animate) {
            indicator.animate()
                .translationX(target)
                .alpha(1f)
                .setStartDelay(0)
                .setDuration(340)
                .setInterpolator(OvershootInterpolator(0.8f))
                .start()
        } else {
            indicator.translationX = target
            indicator.alpha = 1f
        }
    }

    private fun selectTab(i: Int) {
        if (i == tab && !inSettings) return
        inSettings = false
        tab = i
        paintNav(true)
        moveIndicator(true)
        renderPage(ANIM_STAGGER)
    }

    private fun openSettings() {
        if (inSettings) return
        inSettings = true
        paintNav(false)
        moveIndicator(true)
        renderPage(ANIM_FROM_RIGHT)
    }

    private fun closeSettings() {
        if (!inSettings) return
        inSettings = false
        paintNav(true)
        moveIndicator(true)
        renderPage(ANIM_FROM_LEFT)
    }

    // ================= páginas e animações de entrada =================

    private fun renderPage(mode: Int) {
        val old = container.getChildAt(0) as? ScrollView
        val keepY = if (mode == ANIM_NONE && old != null) old.scrollY else 0

        container.removeAllViews()
        val page: LinearLayout = if (inSettings) {
            settingsPage()
        } else {
            when (tab) {
                0 -> homePage()
                1 -> lookPage()
                else -> aboutPage()
            }
        }
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(page)
        container.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))

        when (mode) {
            ANIM_STAGGER -> staggerIn(page)
            ANIM_FROM_RIGHT -> slideIn(sv, dp(80).toFloat())
            ANIM_FROM_LEFT -> slideIn(sv, -dp(80).toFloat())
            else -> {
                if (keepY > 0) sv.post { sv.scrollTo(0, keepY) }
            }
        }
    }

    /** Cada bloco da página sobe e aparece, um depois do outro. */
    private fun staggerIn(page: LinearLayout) {
        for (i in 0 until page.childCount) {
            val v = page.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(28).toFloat()
            v.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay((i * 45L).coerceAtMost(450L))
                .setDuration(360)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
    }

    private fun slideIn(v: View, fromX: Float) {
        v.translationX = fromX
        v.alpha = 0f
        v.animate()
            .translationX(0f)
            .alpha(1f)
            .setStartDelay(0)
            .setDuration(320)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .start()
    }

    private fun circleButton(kind: Int, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Theme.card)
        f.background = bg
        f.addView(
            IconView(this, kind, Theme.accent),
            FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
        )
        f.layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        f.isClickable = true
        f.setOnClickListener { onClick() }
        f.pressable()
        return f
    }

    private fun header(title: String, settingsMode: Boolean): LinearLayout {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        if (settingsMode) {
            h.addView(circleButton(IconView.BACK) { closeSettings() })
            val tp = LinearLayout.LayoutParams(0, WRAP, 1f)
            tp.leftMargin = dp(14)
            h.addView(label(title, 28f, Theme.text, true), tp)
        } else {
            h.addView(label(title, 34f, Theme.text, true), LinearLayout.LayoutParams(0, WRAP, 1f))
            h.addView(circleButton(IconView.PENCIL) { openSettings() })
        }
        return h
    }

    private fun pageShell(title: String, settingsMode: Boolean): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(22), dp(18), dp(24))
        col.addView(header(title, settingsMode))
        return col
    }

    // ================= aba Início =================

    private fun homePage(): LinearLayout {
        val c = Prefs.load(this)
        val col = pageShell(t("app_name"), false)

        val preview = PreviewView(this)
        val pvParams = LinearLayout.LayoutParams(MATCH, dp(124))
        pvParams.topMargin = dp(14)
        col.addView(preview, pvParams)

        // ligar / desligar (cartão sozinho, com a divisória antes da chave)
        var powerRef: RowViews? = null
        val toggle = styledSwitch(c.enabled) { on ->
            Prefs.putBool(this, Prefs.KEY_ENABLED, on)
            val r = powerRef
            if (r != null) {
                r.title.swapText(if (on) t("power_on") else t("power_off"))
                r.subtitle?.swapText(if (on) t("power_on_sub") else t("power_off_sub"))
                tweenBadge(r.badge, if (on) Theme.green else Theme.red)
            }
        }
        val trailing = LinearLayout(this)
        trailing.orientation = LinearLayout.HORIZONTAL
        trailing.gravity = Gravity.CENTER_VERTICAL
        val divider = View(this)
        divider.setBackgroundColor(Theme.divider)
        val divParams = LinearLayout.LayoutParams(dp(1), dp(40))
        divParams.leftMargin = dp(6)
        divParams.rightMargin = dp(16)
        trailing.addView(divider, divParams)
        trailing.addView(toggle)

        val powerRow = buildRow(
            iconBadge(IconView.POWER, if (c.enabled) Theme.green else Theme.red),
            if (c.enabled) t("power_on") else t("power_off"),
            if (c.enabled) t("power_on_sub") else t("power_off_sub"),
            { toggle.performClick() },
            trailing,
            GP_SINGLE
        )
        powerRef = powerRow
        col.addView(powerRow.root)

        // grupo: permissões + bateria, colados como na referência
        val permOk = isServiceEnabled()
        col.addView(
            row(
                iconBadge(IconView.CHECK, if (permOk) Theme.green else Theme.orange),
                t("perm_title"),
                if (permOk) t("perm_ok") else t("perm_missing"),
                { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                null,
                GP_TOP
            )
        )
        val batteryOk = isBatteryUnrestricted()
        col.addView(
            row(
                iconBadge(IconView.BATTERY, if (batteryOk) Theme.green else Theme.orange),
                t("keep_title"),
                if (batteryOk) t("keep_ok") else t("keep_missing"),
                { openBatterySettings(batteryOk) },
                null,
                GP_BOTTOM
            )
        )
        return col
    }

    private fun isServiceEnabled(): Boolean {
        val enabledList = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        val full = "$packageName/${VolumeService::class.java.name}"
        val short = "$packageName/.VolumeService"
        return enabledList.split(':').any {
            it.equals(full, ignoreCase = true) || it.equals(short, ignoreCase = true)
        }
    }

    private fun isBatteryUnrestricted(): Boolean {
        val pm = getSystemService(PowerManager::class.java)
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun openBatterySettings(alreadyOk: Boolean) {
        try {
            if (alreadyOk) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } else {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                Toast.makeText(this, t("open_error"), Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ================= aba Aparência =================

    private fun lookPage(): LinearLayout {
        var cfg = Prefs.load(this)
        val col = pageShell(t("tab_look"), false)

        val preview = PreviewView(this)
        val pvParams = LinearLayout.LayoutParams(MATCH, dp(124))
        pvParams.topMargin = dp(14)
        col.addView(preview, pvParams)

        fun refresh() {
            preview.update(cfg)
        }

        // ----- modelos: as duas, só a linha ou só a barra grande -----
        col.addView(sectionTitle(t("look_models")))
        val cModels = card()
        cModels.addView(
            segmented(
                listOf(t("var_both"), t("var_thin"), t("var_pill")),
                cfg.variant
            ) { i ->
                cfg = cfg.copy(variant = i)
                Prefs.putInt(this, Prefs.KEY_VARIANT, i)
                refresh()
            }
        )
        col.addView(cModels)

        // ----- lado, tamanho e posição -----
        col.addView(sectionTitle(t("look_place")))
        val cPlace = card()
        cPlace.addView(
            segmented(
                listOf(t("side_left"), t("side_right")),
                cfg.side
            ) { i ->
                cfg = cfg.copy(side = i)
                Prefs.putInt(this, Prefs.KEY_SIDE, i)
                refresh()
            }
        )

        val sizeLbl = label(sizeText(cfg.size), 14f, Theme.dim)
        sizeLbl.setPadding(0, dp(18), 0, 0)
        cPlace.addView(sizeLbl)
        cPlace.addView(
            slider(
                Prefs.MAX_SIZE - Prefs.MIN_SIZE,
                cfg.size - Prefs.MIN_SIZE,
                { p ->
                    cfg = cfg.copy(size = Prefs.MIN_SIZE + p)
                    sizeLbl.text = sizeText(cfg.size)
                    refresh()
                },
                { p -> Prefs.putInt(this, Prefs.KEY_SIZE, Prefs.MIN_SIZE + p) }
            )
        )

        val posLbl = label(posText(cfg.pos), 14f, Theme.dim)
        posLbl.setPadding(0, dp(14), 0, 0)
        cPlace.addView(posLbl)
        cPlace.addView(
            slider(
                Prefs.MAX_POS,
                cfg.pos,
                { p ->
                    cfg = cfg.copy(pos = p)
                    posLbl.text = posText(p)
                },
                { p -> Prefs.putInt(this, Prefs.KEY_POS, p) }
            )
        )
        col.addView(cPlace)

        // ----- linha fina -----
        col.addView(sectionTitle(t("look_thin")))
        val cThin = card()
        cThin.addView(
            colorRow(t("thin_color"), cfg.thinColor) { picked ->
                cfg = cfg.copy(thinColor = picked)
                Prefs.putInt(this, Prefs.KEY_THIN_COLOR, picked)
                refresh()
            }
        )
        val thinLbl = label(thinText(cfg.thinWidth), 14f, Theme.dim)
        thinLbl.setPadding(0, dp(14), 0, 0)
        cThin.addView(thinLbl)
        cThin.addView(
            slider(
                Prefs.MAX_THIN - Prefs.MIN_THIN,
                cfg.thinWidth - Prefs.MIN_THIN,
                { p ->
                    cfg = cfg.copy(thinWidth = Prefs.MIN_THIN + p)
                    thinLbl.text = thinText(cfg.thinWidth)
                    refresh()
                },
                { p -> Prefs.putInt(this, Prefs.KEY_THIN_WIDTH, Prefs.MIN_THIN + p) }
            )
        )
        col.addView(cThin)

        // ----- barra grande -----
        col.addView(sectionTitle(t("look_pill")))
        val cPill = card()
        cPill.addView(
            colorRow(t("pill_bg"), cfg.pillBg) { picked ->
                cfg = cfg.copy(pillBg = picked)
                Prefs.putInt(this, Prefs.KEY_PILL_BG, picked)
                refresh()
            }
        )
        cPill.addView(
            colorRow(t("pill_fill"), cfg.pillFill) { picked ->
                cfg = cfg.copy(pillFill = picked)
                Prefs.putInt(this, Prefs.KEY_PILL_FILL, picked)
                refresh()
            }
        )
        val opLbl = label(opacityText(cfg.pillAlpha), 14f, Theme.dim)
        opLbl.setPadding(0, dp(14), 0, 0)
        cPill.addView(opLbl)
        cPill.addView(
            slider(
                90,
                cfg.pillAlpha - 10,
                { p ->
                    cfg = cfg.copy(pillAlpha = 10 + p)
                    opLbl.text = opacityText(cfg.pillAlpha)
                    refresh()
                },
                { p -> Prefs.putInt(this, Prefs.KEY_PILL_ALPHA, 10 + p) }
            )
        )
        col.addView(cPill)

        // ----- tempo na tela -----
        col.addView(sectionTitle(t("look_time")))
        val cTime = card()
        val timeLbl = label(timeText(cfg.showSeconds), 14f, Theme.dim)
        cTime.addView(timeLbl)
        cTime.addView(
            slider(
                Prefs.MAX_SECONDS - Prefs.MIN_SECONDS,
                cfg.showSeconds - Prefs.MIN_SECONDS,
                { p ->
                    cfg = cfg.copy(showSeconds = Prefs.MIN_SECONDS + p)
                    timeLbl.text = timeText(cfg.showSeconds)
                },
                { p -> Prefs.putInt(this, Prefs.KEY_SHOW_SECONDS, Prefs.MIN_SECONDS + p) }
            )
        )
        col.addView(cTime)

        col.addView(
            button(t("reset")) {
                Prefs.resetAppearance(this)
                renderPage(ANIM_NONE)
            }
        )
        return col
    }

    private fun sizeText(v: Int): String = t("size") + ": " + (v * 100 / Prefs.DEF_SIZE) + "%"

    private fun posText(v: Int): String = t("pos") + ": " + v + "% " + t("pos_unit")

    private fun thinText(v: Int): String = t("thin_width") + ": " + v + " dp"

    private fun opacityText(v: Int): String = t("pill_opacity") + ": " + v + "%"

    private fun timeText(v: Int): String = t("time") + ": " + v + " s"

    // ================= configurações (a bolinha com o lápis) =================

    private fun settingsPage(): LinearLayout {
        val col = pageShell(t("settings_title"), true)

        col.addView(sectionTitle(t("lang_title")))
        val cLang = card()
        cLang.addView(
            segmented(
                listOf(t("lang_pt"), t("lang_en")),
                if (I18n.lang == "en") 1 else 0
            ) { i ->
                Prefs.putString(this, Prefs.KEY_LANG, if (i == 1) "en" else "pt")
                recreate()
            }
        )
        col.addView(cLang)

        col.addView(sectionTitle(t("credits")))
        val sub = label(t("credits_sub"), 13f, Theme.dim)
        sub.setPadding(dp(6), 0, 0, dp(2))
        col.addView(sub)
        col.addView(
            row(
                textBadge("IG", Color.rgb(0xE1, 0x30, 0x6C)),
                "Instagram",
                "@mxrais7",
                { openUrl("https://instagram.com/mxrais7") },
                null,
                GP_TOP
            )
        )
        col.addView(
            row(
                textBadge("GH", Color.rgb(0x3D, 0x44, 0x4D)),
                "GitHub",
                "levi9zk",
                { openUrl("https://github.com/levi9zk") },
                null,
                GP_BOTTOM
            )
        )
        return col
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, t("open_error"), Toast.LENGTH_SHORT).show()
        }
    }

    // ================= aba Sobre =================

    private fun versionName(): String {
        return try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
        } catch (e: Exception) {
            "?"
        }
    }

    private fun aboutPage(): LinearLayout {
        val col = pageShell(t("about_title"), false)
        val version = versionName()

        val head = card()
        head.gravity = Gravity.CENTER_HORIZONTAL
        head.setPadding(dp(18), dp(26), dp(18), dp(24))
        head.addView(AppMarkView(this), LinearLayout.LayoutParams(dp(96), dp(96)))
        val name = label(t("app_name"), 26f, Theme.text, true)
        name.setPadding(0, dp(14), 0, 0)
        head.addView(name)
        head.addView(label(t("version").replace("%s", version), 15f, Theme.dim))
        col.addView(head)

        // novidades + ajuda, num grupo só
        col.addView(sectionTitle(t("info_section")))
        col.addView(
            row(
                iconBadge(IconView.STAR, Theme.purple),
                t("whatsnew"),
                t("whatsnew_sub") + " " + version,
                { showText(t("whatsnew"), t("changelog")) },
                null,
                GP_TOP
            )
        )
        col.addView(
            row(
                iconBadge(IconView.INFO, Theme.blue),
                t("help"),
                t("help_sub"),
                { showText(t("help"), t("help_text")) },
                null,
                GP_BOTTOM
            )
        )
        return col
    }

    private fun showText(title: String, message: String) {
        val dialog = AlertDialog.Builder(this, DIALOG_THEME)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(t("ok"), null)
            .show()
        styleDialog(dialog)
    }
}
