package com.volumebar.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()

        val texto = TextView(this).apply {
            text = "Volume Bar\n\n" +
                "1. Toque no botão abaixo.\n" +
                "2. Procure \"Volume Bar\" em Apps instalados (ou Serviços baixados).\n" +
                "3. Ative o serviço e aceite o aviso.\n\n" +
                "Depois disso, ao apertar os botões de volume, a barra fina aparece no lado esquerdo da tela."
            textSize = 16f
        }

        val botao = Button(this).apply {
            text = "Abrir configurações de acessibilidade"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(texto)
            addView(botao)
        }

        setContentView(layout)
    }
}
