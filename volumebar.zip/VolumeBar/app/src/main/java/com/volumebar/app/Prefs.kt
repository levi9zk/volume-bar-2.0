package com.volumebar.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** Foto de todas as configurações num só objeto. */
data class Cfg(
    val enabled: Boolean,
    val side: Int,
    val size: Int,
    val pos: Int,
    val variant: Int,
    val thinColor: Int,
    val thinWidth: Int,
    val pillBg: Int,
    val pillAlpha: Int,
    val pillFill: Int,
    val showSeconds: Int,
    val hideApps: Set<String>
)

object Prefs {
    const val FILE = "volumebar_prefs"

    const val KEY_ENABLED = "enabled"
    const val KEY_SIDE = "side"             // 0 = esquerda, 1 = direita
    const val KEY_SIZE = "size"             // altura da barra, em dp
    const val KEY_POS = "pos"               // posição vertical, em % da altura da tela
    const val KEY_VARIANT = "variant"       // 0 = as duas, 1 = só linha, 2 = só barra grande
    const val KEY_THIN_COLOR = "thin_color"
    const val KEY_THIN_WIDTH = "thin_width" // espessura da linha, em dp
    const val KEY_PILL_BG = "pill_bg"       // cor do fundo da barra grande (o "azul escuro")
    const val KEY_PILL_ALPHA = "pill_alpha" // opacidade do fundo, em %
    const val KEY_PILL_FILL = "pill_fill"   // cor do preenchimento da barra grande
    const val KEY_SHOW_SECONDS = "show_seconds"
    const val KEY_HIDE_APPS = "hide_apps"
    const val KEY_LANG = "lang"

    const val VARIANT_BOTH = 0
    const val VARIANT_THIN = 1
    const val VARIANT_PILL = 2

    const val DEF_SIDE = 0
    const val DEF_SIZE = 120
    const val DEF_POS = 20
    const val DEF_VARIANT = VARIANT_BOTH
    const val DEF_THIN_WIDTH = 5
    const val DEF_PILL_ALPHA = 70
    const val DEF_SECONDS = 7

    val DEF_THIN_COLOR = 0xFFFFFFFF.toInt()
    val DEF_PILL_BG = 0xFF223055.toInt()
    val DEF_PILL_FILL = 0xFFE9ECFF.toInt()
    val DEF_HIDE: Set<String> = setOf("com.instagram.android")

    const val MIN_SIZE = 70
    const val MAX_SIZE = 220
    const val MAX_POS = 80
    const val MIN_THIN = 3
    const val MAX_THIN = 10
    const val MIN_SECONDS = 2
    const val MAX_SECONDS = 12

    fun of(context: Context): SharedPreferences =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun load(context: Context): Cfg {
        val p = of(context)
        val apps: Set<String> = p.getStringSet(KEY_HIDE_APPS, null)?.toSet() ?: DEF_HIDE
        return Cfg(
            enabled = p.getBoolean(KEY_ENABLED, true),
            side = p.getInt(KEY_SIDE, DEF_SIDE),
            size = p.getInt(KEY_SIZE, DEF_SIZE).coerceIn(MIN_SIZE, MAX_SIZE),
            pos = p.getInt(KEY_POS, DEF_POS).coerceIn(0, MAX_POS),
            variant = p.getInt(KEY_VARIANT, DEF_VARIANT).coerceIn(0, 2),
            thinColor = p.getInt(KEY_THIN_COLOR, DEF_THIN_COLOR),
            thinWidth = p.getInt(KEY_THIN_WIDTH, DEF_THIN_WIDTH).coerceIn(MIN_THIN, MAX_THIN),
            pillBg = p.getInt(KEY_PILL_BG, DEF_PILL_BG),
            pillAlpha = p.getInt(KEY_PILL_ALPHA, DEF_PILL_ALPHA).coerceIn(10, 100),
            pillFill = p.getInt(KEY_PILL_FILL, DEF_PILL_FILL),
            showSeconds = p.getInt(KEY_SHOW_SECONDS, DEF_SECONDS).coerceIn(MIN_SECONDS, MAX_SECONDS),
            hideApps = apps
        )
    }

    fun putInt(context: Context, key: String, value: Int) {
        of(context).edit().putInt(key, value).apply()
    }

    fun putBool(context: Context, key: String, value: Boolean) {
        of(context).edit().putBoolean(key, value).apply()
    }

    fun putString(context: Context, key: String, value: String) {
        of(context).edit().putString(key, value).apply()
    }

    fun putSet(context: Context, key: String, value: Set<String>) {
        of(context).edit().putStringSet(key, HashSet(value)).apply()
    }

    /** Volta só a aparência ao padrão (não mexe em ligar/desligar, apps escondidos e idioma). */
    fun resetAppearance(context: Context) {
        of(context).edit()
            .remove(KEY_SIDE)
            .remove(KEY_SIZE)
            .remove(KEY_POS)
            .remove(KEY_VARIANT)
            .remove(KEY_THIN_COLOR)
            .remove(KEY_THIN_WIDTH)
            .remove(KEY_PILL_BG)
            .remove(KEY_PILL_ALPHA)
            .remove(KEY_PILL_FILL)
            .remove(KEY_SHOW_SECONDS)
            .apply()
    }
}

fun luminance(c: Int): Float =
    (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

fun withAlpha(color: Int, pct: Int): Int =
    Color.argb(pct.coerceIn(0, 100) * 255 / 100, Color.red(color), Color.green(color), Color.blue(color))

/** Cor do "trilho" da linha fina: clara se a linha for escura, escura se a linha for clara. */
fun trackFor(thinColor: Int): Int = if (luminance(thinColor) < 0.3f) 0x66FFFFFF else 0x66202020

/** Cor do ícone de alto-falante, escolhida pra ter contraste com o preenchimento. */
fun Cfg.iconColor(): Int =
    if (luminance(pillFill) > 0.55f) (pillBg or 0xFF000000.toInt()) else Color.WHITE
