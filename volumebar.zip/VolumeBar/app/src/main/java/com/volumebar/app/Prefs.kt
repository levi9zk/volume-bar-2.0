package com.volumebar.app

import android.content.Context
import android.content.SharedPreferences

/** Configurações salvas do app (lado, tamanho e posição da barra). */
object Prefs {
    const val FILE = "volumebar_prefs"

    const val KEY_SIDE = "side" // 0 = esquerda, 1 = direita
    const val KEY_SIZE = "size" // altura da barra, em dp
    const val KEY_POS = "pos"   // posição vertical, em % da altura da tela (0 = topo)

    const val DEF_SIDE = 0
    const val DEF_SIZE = 120
    const val DEF_POS = 20

    const val MIN_SIZE = 70
    const val MAX_SIZE = 220
    const val MAX_POS = 80

    fun of(context: Context): SharedPreferences =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}
