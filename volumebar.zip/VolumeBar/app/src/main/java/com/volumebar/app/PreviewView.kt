package com.volumebar.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/** Prévia ao vivo da barra, com as cores e o formato escolhidos. */
class PreviewView(context: Context) : View(context) {

    private var cfg: Cfg = Prefs.load(context)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()

    fun update(c: Cfg) {
        cfg = c
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density

        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            0f, 0f, 0f, h,
            0xFF3B3862.toInt(), 0xFF24252D.toInt(),
            Shader.TileMode.CLAMP
        )
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, 26f * d, 26f * d, paint)
        paint.shader = null

        val c = cfg
        val barH = minOf(h * 0.8f, 100f * d * c.size / 120f)
        val k = barH / (c.size * d)
        val pillW = barH * 0.36f
        val thinW = c.thinWidth * d * k
        val margin = 14f * d
        val top = (h - barH) / 2f
        val frac = 0.6f
        val gap = 28f * d
        val right = c.side == 1

        val showThin = c.variant != Prefs.VARIANT_PILL
        val showPill = c.variant != Prefs.VARIANT_THIN

        val thinX: Float
        val pillX: Float
        if (!right) {
            thinX = margin
            pillX = if (showThin) margin + thinW + gap else margin
        } else {
            thinX = w - margin - thinW
            pillX = if (showThin) thinX - gap - pillW else w - margin - pillW
        }

        if (showThin) {
            drawBar(canvas, thinX, top, thinW, barH, frac, trackFor(c.thinColor), c.thinColor, thinW / 2f)
        }
        if (showPill) {
            drawBar(
                canvas, pillX, top, pillW, barH, frac,
                withAlpha(c.pillBg, c.pillAlpha), c.pillFill, pillW * 0.32f
            )
            val iconSize = pillW * 0.55f
            drawSpeaker(
                canvas,
                pillX + (pillW - iconSize) / 2f,
                top + barH - pillW * 0.22f - iconSize,
                iconSize,
                c.iconColor()
            )
        }
    }

    private fun drawBar(
        canvas: Canvas,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        frac: Float,
        trackColor: Int,
        fillColor: Int,
        radius: Float
    ) {
        rect.set(x, y, x + w, y + h)
        paint.color = trackColor
        canvas.drawRoundRect(rect, radius, radius, paint)

        clip.reset()
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        paint.color = fillColor
        canvas.drawRect(x, y + h * (1f - frac), x + w, y + h, paint)
        canvas.restore()
    }
}

/** Logo do app (cápsula vertical) usado na aba Sobre. */
class AppMarkView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        paint.style = Paint.Style.FILL
        paint.color = Theme.accent
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, w * 0.26f, w * 0.26f, paint)

        val bw = w * 0.2f
        val bh = h * 0.56f
        val bx = (w - bw) / 2f
        val by = (h - bh) / 2f

        rect.set(bx, by, bx + bw, by + bh)
        paint.color = 0xFF223055.toInt()
        canvas.drawRoundRect(rect, bw / 2f, bw / 2f, paint)

        clip.reset()
        clip.addRoundRect(rect, bw / 2f, bw / 2f, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        paint.color = 0xFFFFFFFF.toInt()
        canvas.drawRect(bx, by + bh * 0.4f, bx + bw, by + bh, paint)
        canvas.restore()
    }
}
