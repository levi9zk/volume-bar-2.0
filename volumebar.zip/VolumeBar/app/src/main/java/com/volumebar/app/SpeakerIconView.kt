package com.volumebar.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

private val spFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

private val spWave = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    style = Paint.Style.STROKE
    strokeCap = Paint.Cap.ROUND
}

private val spPath = Path()
private val spArc = RectF()

/** Desenha o alto-falante (corpo + duas ondinhas) numa área quadrada. */
fun drawSpeaker(canvas: Canvas, left: Float, top: Float, size: Float, color: Int) {
    val w = size
    val h = size

    canvas.save()
    canvas.translate(left, top)

    spFill.color = color
    spWave.color = color

    spPath.reset()
    spPath.moveTo(w * 0.08f, h * 0.38f)
    spPath.lineTo(w * 0.26f, h * 0.38f)
    spPath.lineTo(w * 0.46f, h * 0.20f)
    spPath.lineTo(w * 0.46f, h * 0.80f)
    spPath.lineTo(w * 0.26f, h * 0.62f)
    spPath.lineTo(w * 0.08f, h * 0.62f)
    spPath.close()
    canvas.drawPath(spPath, spFill)

    spWave.strokeWidth = w * 0.08f
    val cx = w * 0.46f
    val cy = h * 0.5f

    var r = w * 0.22f
    spArc.set(cx - r, cy - r, cx + r, cy + r)
    canvas.drawArc(spArc, -45f, 90f, false, spWave)

    r = w * 0.38f
    spArc.set(cx - r, cy - r, cx + r, cy + r)
    canvas.drawArc(spArc, -45f, 90f, false, spWave)

    canvas.restore()
}

/** View com o ícone de alto-falante; a cor pode ser trocada. */
class SpeakerIconView(context: Context) : View(context) {

    var iconColor: Int = Color.rgb(0x5B, 0x66, 0x94)

    override fun onDraw(canvas: Canvas) {
        drawSpeaker(canvas, 0f, 0f, minOf(width, height).toFloat(), iconColor)
    }
}
