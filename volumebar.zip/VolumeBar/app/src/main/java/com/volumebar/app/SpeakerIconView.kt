package com.volumebar.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

/** Ícone de alto-falante desenhado na mão (corpo + duas ondinhas). */
class SpeakerIconView(context: Context) : View(context) {

    private val iconColor = Color.rgb(0x5B, 0x66, 0x94)

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = iconColor
        style = Paint.Style.FILL
    }

    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = iconColor
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val body = Path()
    private val arc = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        body.reset()
        body.moveTo(w * 0.08f, h * 0.38f)
        body.lineTo(w * 0.26f, h * 0.38f)
        body.lineTo(w * 0.46f, h * 0.20f)
        body.lineTo(w * 0.46f, h * 0.80f)
        body.lineTo(w * 0.26f, h * 0.62f)
        body.lineTo(w * 0.08f, h * 0.62f)
        body.close()
        canvas.drawPath(body, fillPaint)

        wavePaint.strokeWidth = w * 0.08f
        val cx = w * 0.46f
        val cy = h * 0.5f

        var r = w * 0.22f
        arc.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(arc, -45f, 90f, false, wavePaint)

        r = w * 0.38f
        arc.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(arc, -45f, 90f, false, wavePaint)
    }
}
