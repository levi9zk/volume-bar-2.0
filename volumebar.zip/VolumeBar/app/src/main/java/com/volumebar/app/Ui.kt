package com.volumebar.app

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
const val DIALOG_THEME = android.R.style.Theme_DeviceDefault_Dialog_Alert

object Theme {
    val bg = Color.rgb(0x12, 0x12, 0x16)
    val card = Color.rgb(0x25, 0x26, 0x2E)
    val nav = Color.rgb(0x2B, 0x2C, 0x35)
    val chip = Color.rgb(0x32, 0x33, 0x3D)
    val accent = Color.rgb(0xC9, 0xC5, 0xF5)
    val onAccent = Color.rgb(0x1E, 0x1B, 0x3A)
    val text = Color.WHITE
    val dim = Color.rgb(0xA6, 0xA9, 0xB8)
    val green = Color.rgb(0x34, 0xC7, 0x59)
    val orange = Color.rgb(0xFF, 0x9F, 0x0A)
    val red = Color.rgb(0xFF, 0x45, 0x3A)
    val purple = Color.rgb(0xBF, 0x5A, 0xF2)
    val blue = Color.rgb(0x0A, 0x84, 0xFF)
    val indigo = Color.rgb(0x5E, 0x5C, 0xE6)
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun rounded(color: Int, radiusPx: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radiusPx
    return g
}

fun Context.label(text: String, sp: Float, color: Int, bold: Boolean = false): TextView {
    val tv = TextView(this)
    tv.text = text
    tv.textSize = sp
    tv.setTextColor(color)
    if (bold) tv.typeface = Typeface.DEFAULT_BOLD
    return tv
}

fun Context.sectionTitle(text: String): TextView {
    val tv = label(text, 14f, Theme.accent, true)
    tv.setPadding(dp(4), dp(20), 0, dp(2))
    return tv
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.background = rounded(Theme.card, dp(20).toFloat())
    c.setPadding(dp(18), dp(14), dp(18), dp(18))
    c.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
    return c
}

fun Context.iconBadge(kind: Int, color: Int): FrameLayout {
    val f = FrameLayout(this)
    f.background = rounded(color, dp(14).toFloat())
    f.addView(
        IconView(this, kind, Color.WHITE),
        FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER)
    )
    return f
}

fun Context.textBadge(text: String, color: Int): FrameLayout {
    val f = FrameLayout(this)
    f.background = rounded(color, dp(14).toFloat())
    val tv = label(text, 15f, Color.WHITE, true)
    tv.gravity = Gravity.CENTER
    f.addView(tv, FrameLayout.LayoutParams(MATCH, MATCH))
    return f
}

/** Linha em cartão: ícone, título, subtítulo e (seta | chave | nada) à direita. */
fun Context.row(
    badge: View,
    title: String,
    subtitle: String?,
    onClick: (() -> Unit)?,
    trailing: View?
): LinearLayout {
    val r = LinearLayout(this)
    r.orientation = LinearLayout.HORIZONTAL
    r.gravity = Gravity.CENTER_VERTICAL
    r.background = rounded(Theme.card, dp(20).toFloat())
    r.setPadding(dp(14), dp(14), dp(16), dp(14))
    r.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }

    r.addView(badge, LinearLayout.LayoutParams(dp(46), dp(46)))

    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.addView(label(title, 16f, Theme.text, true))
    if (subtitle != null) {
        val sub = label(subtitle, 13f, Theme.dim)
        sub.setPadding(0, dp(2), 0, 0)
        col.addView(sub)
    }
    val colParams = LinearLayout.LayoutParams(0, WRAP, 1f)
    colParams.leftMargin = dp(14)
    colParams.rightMargin = dp(8)
    r.addView(col, colParams)

    if (trailing != null) {
        r.addView(trailing)
    } else if (onClick != null) {
        r.addView(
            IconView(this, IconView.CHEVRON, Theme.dim),
            LinearLayout.LayoutParams(dp(20), dp(20))
        )
    }
    if (onClick != null) {
        r.isClickable = true
        r.setOnClickListener { onClick() }
    }
    return r
}

fun Context.button(text: String, onClick: () -> Unit): TextView {
    val b = label(text, 15f, Theme.onAccent, true)
    b.gravity = Gravity.CENTER
    b.background = rounded(Theme.accent, dp(14).toFloat())
    b.layoutParams = LinearLayout.LayoutParams(MATCH, dp(48)).apply { topMargin = dp(18) }
    b.isClickable = true
    b.setOnClickListener { onClick() }
    return b
}

fun Context.styledSwitch(checked: Boolean, onChange: (Boolean) -> Unit): Switch {
    val sw = Switch(this)
    sw.isChecked = checked
    val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
    sw.thumbTintList = ColorStateList(
        states,
        intArrayOf(Theme.onAccent, Color.rgb(0x9A, 0x9C, 0xAD))
    )
    sw.trackTintList = ColorStateList(states, intArrayOf(Theme.accent, Theme.chip))
    sw.setOnCheckedChangeListener { _, value -> onChange(value) }
    return sw
}

fun Context.segmented(
    labels: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit
): LinearLayout {
    val box = LinearLayout(this)
    box.orientation = LinearLayout.HORIZONTAL
    box.background = rounded(Theme.chip, dp(14).toFloat())
    box.setPadding(dp(4), dp(4), dp(4), dp(4))
    box.layoutParams = LinearLayout.LayoutParams(MATCH, dp(50)).apply { topMargin = dp(10) }

    val items = ArrayList<TextView>()

    fun paint(sel: Int) {
        for (i in items.indices) {
            val tv = items[i]
            if (i == sel) {
                tv.background = rounded(Theme.accent, dp(11).toFloat())
                tv.setTextColor(Theme.onAccent)
            } else {
                tv.background = null
                tv.setTextColor(Theme.dim)
            }
        }
    }

    for (i in labels.indices) {
        val tv = label(labels[i], 13f, Theme.dim, true)
        tv.gravity = Gravity.CENTER
        tv.maxLines = 1
        tv.layoutParams = LinearLayout.LayoutParams(0, MATCH, 1f)
        tv.isClickable = true
        tv.setOnClickListener {
            paint(i)
            onSelect(i)
        }
        items.add(tv)
        box.addView(tv)
    }
    paint(selected)
    return box
}

fun Context.slider(
    max: Int,
    progress: Int,
    onChange: (Int) -> Unit,
    onDone: (Int) -> Unit
): SeekBar {
    val sb = SeekBar(this)
    sb.max = max
    sb.progress = progress
    sb.progressTintList = ColorStateList.valueOf(Theme.accent)
    sb.thumbTintList = ColorStateList.valueOf(Theme.accent)
    sb.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) }
    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            onChange(p)
        }

        override fun onStartTrackingTouch(s: SeekBar) {}

        override fun onStopTrackingTouch(s: SeekBar) {
            onDone(s.progress)
        }
    })
    return sb
}

private fun Context.swatch(color: Int): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.OVAL
    g.setColor(color or 0xFF000000.toInt())
    g.setStroke(dp(2), 0x55FFFFFF)
    return g
}

/** Linha "título + bolinha da cor atual"; ao tocar, abre o seletor de cor. */
fun Context.colorRow(title: String, color: Int, onPick: (Int) -> Unit): LinearLayout {
    var current = color
    val r = LinearLayout(this)
    r.orientation = LinearLayout.HORIZONTAL
    r.gravity = Gravity.CENTER_VERTICAL
    r.setPadding(0, dp(14), 0, dp(4))
    r.addView(label(title, 14f, Theme.text), LinearLayout.LayoutParams(0, WRAP, 1f))

    val sw = View(this)
    sw.background = swatch(current)
    r.addView(sw, LinearLayout.LayoutParams(dp(34), dp(34)))

    r.isClickable = true
    r.setOnClickListener {
        showColorDialog(title, current) { picked ->
            current = picked
            sw.background = swatch(picked)
            onPick(picked)
        }
    }
    return r
}

private val PALETTE = intArrayOf(
    0xFFFFFFFF.toInt(), 0xFFE9ECFF.toInt(), 0xFFC9C5F5.toInt(), 0xFF5B8CFF.toInt(),
    0xFF223055.toInt(), 0xFF000000.toInt(), 0xFF8A8FA3.toInt(),
    0xFFFF5A5F.toInt(), 0xFFFFB040.toInt(), 0xFFFFE24A.toInt(), 0xFF4CD97B.toInt(),
    0xFF2EC4B6.toInt(), 0xFFFF6FB5.toInt(), 0xFFA06CFF.toInt()
)

/** Seletor de cor: bolinhas prontas + controles de vermelho, verde e azul. */
fun Context.showColorDialog(title: String, initial: Int, onPick: (Int) -> Unit) {
    val opaque = 0xFF000000.toInt()
    var cur = initial or opaque
    var updating = false

    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(20), dp(16), dp(20), dp(4))

    val preview = View(this)
    preview.background = rounded(cur, dp(12).toFloat())
    col.addView(preview, LinearLayout.LayoutParams(MATCH, dp(44)))

    val bars = ArrayList<SeekBar>()

    fun setColor(c: Int, fromBars: Boolean) {
        cur = c or opaque
        preview.background = rounded(cur, dp(12).toFloat())
        if (!fromBars && bars.size == 3) {
            updating = true
            bars[0].progress = Color.red(cur)
            bars[1].progress = Color.green(cur)
            bars[2].progress = Color.blue(cur)
            updating = false
        }
    }

    // bolinhas prontas, em duas fileiras
    var rowBox: LinearLayout? = null
    for (i in PALETTE.indices) {
        if (i % 7 == 0) {
            rowBox = LinearLayout(this)
            rowBox.orientation = LinearLayout.HORIZONTAL
            rowBox.setPadding(0, dp(12), 0, 0)
            col.addView(rowBox)
        }
        val color = PALETTE[i]
        val dot = View(this)
        dot.background = swatch(color)
        dot.setOnClickListener { setColor(color, false) }
        val lp = LinearLayout.LayoutParams(dp(34), dp(34))
        lp.rightMargin = dp(8)
        rowBox?.addView(dot, lp)
    }

    val names = arrayOf("R", "G", "B")
    val tints = intArrayOf(0xFFFF5A5F.toInt(), 0xFF4CD97B.toInt(), 0xFF5B8CFF.toInt())
    val start = intArrayOf(Color.red(cur), Color.green(cur), Color.blue(cur))

    for (i in 0 until 3) {
        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL
        line.setPadding(0, dp(10), 0, 0)
        line.addView(label(names[i], 14f, Theme.dim, true), LinearLayout.LayoutParams(dp(20), WRAP))

        val sb = SeekBar(this)
        sb.max = 255
        sb.progress = start[i]
        sb.progressTintList = ColorStateList.valueOf(tints[i])
        sb.thumbTintList = ColorStateList.valueOf(tints[i])
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (updating || !fromUser || bars.size < 3) return
                setColor(Color.rgb(bars[0].progress, bars[1].progress, bars[2].progress), true)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}

            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        bars.add(sb)
        line.addView(sb, LinearLayout.LayoutParams(0, WRAP, 1f))
        col.addView(line)
    }

    AlertDialog.Builder(this, DIALOG_THEME)
        .setTitle(title)
        .setView(col)
        .setPositiveButton(I18n.t("ok")) { _, _ -> onPick(cur) }
        .setNegativeButton(I18n.t("cancel"), null)
        .show()
}
