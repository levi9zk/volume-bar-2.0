package com.volumebar.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.roundToInt

class VolumeService : AccessibilityService() {

    // ===== AJUSTES (mexa aqui pra mudar o visual e os tempos) =====
    private val thinWidthDp = 5          // grossura da linha fina
    private val thinHeightDp = 110       // altura da linha fina
    private val pillWidthDp = 46         // largura da barra grande (modo arrastar)
    private val pillHeightDp = 170       // altura da barra grande
    private val marginDp = 8             // distância da borda esquerda da tela
    private val grabDp = 14              // área extra ao lado da linha pra conseguir pegar com o dedo
    private val topFraction = 0.20f      // posição vertical: 0 = topo, 0.5 = meio da tela
    private val slideDp = 70             // quanto ela desliza pro lado ao entrar/sair
    private val thinVisibleMs = 7000L    // tempo da linha fina na tela
    private val pillVisibleMs = 3000L    // tempo da barra grande parada, sem mexer
    private val repeatStartMs = 300L     // quanto segurar o botão até começar a repetir
    private val repeatEveryMs = 80L      // intervalo da repetição ao segurar o botão
    // ===============================================================

    private enum class Mode { HIDDEN, THIN, EXPANDED }

    private var mode = Mode.HIDDEN

    private lateinit var audio: AudioManager
    private lateinit var wm: WindowManager

    private var root: FrameLayout? = null
    private var content: FrameLayout? = null
    private var thinTrack: FrameLayout? = null
    private var thinFill: View? = null
    private var pill: FrameLayout? = null
    private var pillFill: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var windowExpanded = false

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { hideBar() }

    // botão de volume segurado
    private var heldDirection = 0
    private var heldSteps = 0
    private val repeatRunnable = object : Runnable {
        override fun run() {
            if (heldDirection == 0) return
            val changed = stepVolume(heldDirection)
            heldSteps++
            if (!changed || heldSteps > 200) {
                heldDirection = 0 // chegou no limite
                return
            }
            handler.postDelayed(this, repeatEveryMs)
        }
    }

    // arrastar com o dedo
    private var dragging = false
    private var downY = 0f
    private var startY = 0f
    private var startFrac = 0f
    private val touchSlop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    private val baseFlags =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
    private val idleFlags = baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val touchFlags = baseFlags or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay()
    }

    // A janela é criada uma única vez e fica sempre ali (invisível e sem pegar toque).
    private fun buildOverlay() {
        if (root != null) return

        val tW = dp(thinWidthDp)
        val tH = dp(thinHeightDp)
        val pW = dp(pillWidthDp)
        val pH = dp(pillHeightDp)

        // ----- linha fina -----
        val thinBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = tW / 2f
            setColor(0x66202020)
        }
        val thinFillView = View(this).apply {
            setBackgroundColor(Color.WHITE)
            pivotY = tH.toFloat()
            scaleY = 0f
        }
        val thinTrackView = FrameLayout(this).apply {
            background = thinBg
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            addView(
                thinFillView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        // ----- barra grande (estilo iPhone) -----
        val pillBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(16).toFloat()
            setColor(Color.argb(0xB3, 0x22, 0x30, 0x55))
        }
        val pillFillView = View(this).apply {
            setBackgroundColor(Color.rgb(0xE9, 0xEC, 0xFF))
            pivotY = pH.toFloat()
            scaleY = 0f
        }
        val icon = SpeakerIconView(this)
        val pillView = FrameLayout(this).apply {
            background = pillBg
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            addView(
                pillFillView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            addView(
                icon,
                FrameLayout.LayoutParams(
                    dp(26),
                    dp(26),
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                ).apply { bottomMargin = dp(10) }
            )
            pivotX = 0f
            pivotY = pH / 2f
            alpha = 0f
        }

        // ----- conteúdo que desliza pra dentro/fora -----
        val contentView = FrameLayout(this).apply {
            addView(
                thinTrackView,
                FrameLayout.LayoutParams(tW, tH, Gravity.TOP or Gravity.START).apply {
                    leftMargin = dp(marginDp)
                }
            )
            addView(
                pillView,
                FrameLayout.LayoutParams(pW, pH, Gravity.TOP or Gravity.START).apply {
                    leftMargin = dp(marginDp)
                }
            )
            alpha = 0f
            translationX = -dp(slideDp).toFloat()
        }

        val rootView = FrameLayout(this).apply {
            addView(
                contentView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            setOnTouchListener { _, e -> onOverlayTouch(e) }
        }

        val p = WindowManager.LayoutParams(
            dp(marginDp + thinWidthDp + grabDp),
            tH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            idleFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = (resources.displayMetrics.heightPixels * topFraction).toInt()
        }

        try {
            wm.addView(rootView, p)
            root = rootView
            content = contentView
            thinTrack = thinTrackView
            thinFill = thinFillView
            pill = pillView
            pillFill = pillFillView
            params = p
        } catch (e: Exception) {
            // sem permissão de overlay: ignora
        }
    }

    // ================= botões de volume =================

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val direction = when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> AudioManager.ADJUST_RAISE
            KeyEvent.KEYCODE_VOLUME_DOWN -> AudioManager.ADJUST_LOWER
            else -> return false
        }

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                // a repetição ao segurar é feita aqui dentro (repeatRunnable)
                if (event.repeatCount == 0) {
                    handler.removeCallbacks(repeatRunnable)
                    heldDirection = direction
                    heldSteps = 0
                    stepVolume(direction)
                    handler.postDelayed(repeatRunnable, repeatStartMs)
                }
            }
            KeyEvent.ACTION_UP -> {
                if (heldDirection == direction) {
                    heldDirection = 0
                    handler.removeCallbacks(repeatRunnable)
                }
            }
        }
        // true = o painel padrão do Android não aparece
        return true
    }

    private fun currentStream(): Int {
        return when (audio.mode) {
            AudioManager.MODE_IN_CALL,
            AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
            else -> AudioManager.STREAM_MUSIC
        }
    }

    private fun stepVolume(direction: Int): Boolean {
        val stream = currentStream()
        val before = audio.getStreamVolume(stream)
        audio.adjustStreamVolume(stream, direction, 0)
        showBar(stream)
        return audio.getStreamVolume(stream) != before
    }

    // ================= mostrar / esconder =================

    private fun showBar(stream: Int) {
        val c = content ?: return
        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        val frac = audio.getStreamVolume(stream).toFloat() / max.toFloat()

        handler.removeCallbacks(hideRunnable)

        if (mode == Mode.HIDDEN) {
            prepareThin()
            setFill(frac, false)
            mode = Mode.THIN
        } else {
            setFill(frac, true)
        }

        if (c.translationX != 0f || c.alpha != 1f) {
            c.animate().cancel()
            c.animate()
                .translationX(0f)
                .alpha(1f)
                .setDuration(220)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }

        scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        val delay = if (mode == Mode.EXPANDED) pillVisibleMs else thinVisibleMs
        handler.postDelayed(hideRunnable, delay)
    }

    private fun hideBar() {
        handler.removeCallbacks(hideRunnable)
        val c = content ?: return
        if (mode == Mode.HIDDEN) return
        mode = Mode.HIDDEN
        dragging = false

        // para de pegar toque na hora
        applyWindow(windowExpanded, false)

        // desliza de volta pra fora da tela pelo lado esquerdo
        c.animate().cancel()
        c.animate()
            .translationX(-dp(slideDp).toFloat())
            .alpha(0f)
            .setDuration(220)
            .setInterpolator(AccelerateInterpolator())
            .start()
    }

    private fun prepareThin() {
        thinTrack?.let {
            it.animate().cancel()
            it.alpha = 1f
        }
        pill?.let {
            it.animate().cancel()
            it.alpha = 0f
        }
        applyWindow(false, true)
    }

    private fun expand() {
        if (mode != Mode.THIN) return
        mode = Mode.EXPANDED
        applyWindow(true, true)

        thinTrack?.let {
            it.animate().cancel()
            it.animate().alpha(0f).setDuration(120).start()
        }
        pill?.let {
            it.animate().cancel()
            it.scaleX = 0.6f
            it.animate()
                .alpha(1f)
                .scaleX(1f)
                .setDuration(180)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    private fun applyWindow(expanded: Boolean, touchable: Boolean) {
        val p = params ?: return
        val r = root ?: return
        windowExpanded = expanded
        p.width = if (expanded) {
            dp(marginDp + pillWidthDp + 2)
        } else {
            dp(marginDp + thinWidthDp + grabDp)
        }
        p.height = dp(if (expanded) pillHeightDp else thinHeightDp)
        p.flags = if (touchable) touchFlags else idleFlags
        try {
            wm.updateViewLayout(r, p)
        } catch (e: Exception) {
            // ignora
        }
    }

    private fun setFill(frac: Float, animate: Boolean) {
        for (f in listOfNotNull(thinFill, pillFill)) {
            f.animate().cancel()
            if (animate) {
                f.animate()
                    .scaleY(frac)
                    .setDuration(90)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
            } else {
                f.scaleY = frac
            }
        }
    }

    // ================= toque / arrastar =================

    private fun onOverlayTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            // tocou em qualquer lugar fora da barra: some
            MotionEvent.ACTION_OUTSIDE -> {
                hideBar()
                return true
            }
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacks(hideRunnable)
                downY = e.y
                if (mode == Mode.EXPANDED) beginDrag(e.y) else dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == Mode.THIN && abs(e.y - downY) > touchSlop) {
                    expand()
                    beginDrag(e.y)
                }
                if (dragging) dragTo(e.y)
                return true
            }
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                if (mode != Mode.HIDDEN) scheduleHide()
                return true
            }
        }
        return false
    }

    private fun beginDrag(y: Float) {
        val stream = currentStream()
        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        startFrac = audio.getStreamVolume(stream).toFloat() / max.toFloat()
        startY = y
        dragging = true
    }

    // O volume muda de forma relativa ao movimento do dedo (sem pulos quando você encosta).
    private fun dragTo(y: Float) {
        val stream = currentStream()
        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        val frac = (startFrac + (startY - y) / dp(pillHeightDp)).coerceIn(0f, 1f)
        val level = (frac * max).roundToInt()
        if (audio.getStreamVolume(stream) != level) {
            audio.setStreamVolume(stream, level, 0)
        }
        setFill(frac, false)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(repeatRunnable)
        try {
            root?.let { wm.removeView(it) }
        } catch (e: Exception) {
            // ignora
        }
        root = null
        content = null
        thinTrack = null
        thinFill = null
        pill = null
        pillFill = null
        params = null
        super.onDestroy()
    }
}
