package com.volumebar.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout

class VolumeService : AccessibilityService() {

    // ===== AJUSTES (mexa aqui pra mudar o visual) =====
    private val barWidthDp = 5          // grossura da barra
    private val barHeightDp = 110       // altura da barra
    private val marginDp = 8            // distância da borda esquerda da tela
    private val topFraction = 0.20f     // posição vertical: 0 = topo, 0.5 = meio da tela
    private val slideDp = 20            // quanto ela desliza pro lado ao entrar/sair
    private val visibleMs = 1500L       // tempo que fica na tela depois do último toque
    // ==================================================

    private lateinit var audio: AudioManager
    private lateinit var wm: WindowManager

    private var root: FrameLayout? = null
    private var track: FrameLayout? = null
    private var fill: View? = null

    private var shown = false

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { hideBar() }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay()
    }

    // A janela é criada uma única vez e fica sempre ali (invisível).
    // Assim não tem custo de criar/remover janela a cada toque, e a animação fica fluida.
    private fun buildOverlay() {
        if (root != null) return

        val barW = dp(barWidthDp)
        val barH = dp(barHeightDp)

        val trackBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = barW / 2f
            setColor(0x66202020)
        }

        val fillView = View(this).apply {
            setBackgroundColor(Color.WHITE)
            pivotY = barH.toFloat() // cresce de baixo pra cima
            scaleY = 0f
        }

        val trackView = FrameLayout(this).apply {
            background = trackBg
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            addView(
                fillView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            alpha = 0f
            translationX = -dp(slideDp).toFloat()
        }

        val rootView = FrameLayout(this).apply {
            addView(
                trackView,
                FrameLayout.LayoutParams(barW, barH).apply {
                    leftMargin = dp(marginDp)
                }
            )
        }

        val params = WindowManager.LayoutParams(
            dp(marginDp) + barW + dp(2),
            barH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = (resources.displayMetrics.heightPixels * topFraction).toInt()
        }

        try {
            wm.addView(rootView, params)
            root = rootView
            track = trackView
            fill = fillView
        } catch (e: Exception) {
            // sem permissão de overlay: ignora
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN) {
            val direction = if (code == KeyEvent.KEYCODE_VOLUME_UP) {
                AudioManager.ADJUST_RAISE
            } else {
                AudioManager.ADJUST_LOWER
            }
            val stream = currentStream()
            // flag 0 = não mostra o painel padrão do Android
            audio.adjustStreamVolume(stream, direction, 0)
            showBar(stream)
        }
        return true
    }

    private fun currentStream(): Int {
        return when (audio.mode) {
            AudioManager.MODE_IN_CALL,
            AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
            else -> AudioManager.STREAM_MUSIC
        }
    }

    private fun showBar(stream: Int) {
        val t = track ?: return
        val f = fill ?: return

        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        val vol = audio.getStreamVolume(stream)
        val fraction = vol.toFloat() / max.toFloat()

        handler.removeCallbacks(hideRunnable)

        if (!shown) {
            // primeira aparição: já entra com o nível certo
            f.animate().cancel()
            f.scaleY = fraction
            shown = true
        } else {
            f.animate()
                .scaleY(fraction)
                .setDuration(90)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }

        // desliza da borda pra dentro
        if (t.translationX != 0f || t.alpha != 1f) {
            t.animate().cancel()
            t.animate()
                .translationX(0f)
                .alpha(1f)
                .setDuration(220)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }

        handler.postDelayed(hideRunnable, visibleMs)
    }

    private fun hideBar() {
        val t = track ?: return
        // desliza de volta pra fora da tela pelo lado esquerdo
        t.animate().cancel()
        t.animate()
            .translationX(-dp(slideDp).toFloat())
            .alpha(0f)
            .setDuration(220)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { shown = false }
            .start()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(hideRunnable)
        try {
            root?.let { wm.removeView(it) }
        } catch (e: Exception) {
            // ignora
        }
        root = null
        track = null
        fill = null
        super.onDestroy()
    }
}
