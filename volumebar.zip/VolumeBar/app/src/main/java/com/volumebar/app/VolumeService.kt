package com.volumebar.app

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.roundToInt

class VolumeService : AccessibilityService() {

    // ===== AJUSTES FIXOS (o resto vem da tela de configurações do app) =====
    private val marginDp = 8             // distância da borda da tela
    private val grabDp = 14              // área extra ao lado da linha pra conseguir pegar com o dedo
    private val slideExtraDp = 12        // folga extra pra barra sair toda da tela ao deslizar
    private val pillVisibleMs = 3000L    // tempo da barra grande parada, sem mexer
    private val repeatStartMs = 300L     // quanto segurar o botão até começar a repetir
    private val repeatEveryMs = 80L      // intervalo da repetição ao segurar o botão
    // ========================================================================

    private enum class Mode { HIDDEN, THIN, EXPANDED }

    private var mode = Mode.HIDDEN

    private lateinit var audio: AudioManager
    private lateinit var wm: WindowManager

    // configurações vindas do app
    private var enabled = true
    private var variant = Prefs.VARIANT_BOTH
    private var hideApps: Set<String> = emptySet()
    private var thinColor = Color.WHITE
    private var pillBgColor = 0xB3223055.toInt()
    private var pillFillColor = Color.WHITE
    private var iconCol = Color.BLACK
    private var showMs = 7000L

    // medidas calculadas (em pixels)
    private var onRight = false
    private var barH = 0        // altura: igual na linha fina e na barra grande
    private var thinW = 0       // largura da linha fina
    private var pillW = 0       // largura da barra grande (proporcional à altura)
    private var marginPx = 0
    private var grabPx = 0
    private var topY = 0
    private var slidePx = 0f    // já com sinal: negativo = esquerda, positivo = direita

    // app que está aberto agora (pra esconder a barra em apps escolhidos)
    private var foregroundPkg = ""

    private var root: FrameLayout? = null
    private var content: FrameLayout? = null
    private var thinTrack: FrameLayout? = null
    private var thinFill: View? = null
    private var pill: FrameLayout? = null
    private var pillFill: View? = null
    private var params: WindowManager.LayoutParams? = null

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { hideBar() }

    // botão de volume segurado
    private var heldDirection = 0
    private var heldSteps = 0
    private val repeatRunnable = object : Runnable {
        override fun run() {
            if (heldDirection == 0) return
            val changed = stepVolume(heldDirection)
            heldSteps++
            if (!changed || heldSteps > 200) {
                heldDirection = 0 // chegou no limite
                return
            }
            handler.postDelayed(this, repeatEveryMs)
        }
    }

    // arrastar com o dedo
    private var dragging = false
    private var downY = 0f
    private var startY = 0f
    private var startFrac = 0f
    private val touchSlop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    // quando mexem nas configurações do app, refaz a barra (e mostra ela, se fizer sentido)
    private var pendingShow = false
    private val applyPrefsRunnable = Runnable {
        rebuildOverlay()
        if (pendingShow && enabled && !isHiddenHere() && root != null) {
            showBar(currentStream())
        }
        pendingShow = false
    }
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != Prefs.KEY_LANG) {
            if (key != Prefs.KEY_ENABLED && key != Prefs.KEY_HIDE_APPS) pendingShow = true
            handler.removeCallbacks(applyPrefsRunnable)
            handler.postDelayed(applyPrefsRunnable, 150)
        }
    }

    private val baseFlags =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
    private val idleFlags = baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val touchFlags = baseFlags or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        loadSettings()
        buildOverlay()
        Prefs.of(this).registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::wm.isInitialized) rebuildOverlay() // girou a tela: recalcula a posição
    }

    private fun loadSettings() {
        val c = Prefs.load(this)

        enabled = c.enabled
        hideApps = c.hideApps
        variant = c.variant
        thinColor = c.thinColor
        pillBgColor = withAlpha(c.pillBg, c.pillAlpha)
        pillFillColor = c.pillFill
        iconCol = c.iconColor()
        showMs = c.showSeconds * 1000L

        onRight = c.side == 1
        barH = dp(c.size)
        thinW = dp(c.thinWidth)
        pillW = (barH * 0.36f).toInt()
        marginPx = dp(marginDp)
        grabPx = dp(grabDp)

        val screenH = resources.displayMetrics.heightPixels
        val maxTop = (screenH - barH - dp(24)).coerceAtLeast(0)
        topY = (screenH * c.pos / 100f).toInt().coerceAtMost(maxTop)

        val dist = (marginPx + pillW + dp(slideExtraDp)).toFloat()
        slidePx = if (onRight) dist else -dist
    }

    private fun rebuildOverlay() {
        destroyOverlay()
        loadSettings()
        buildOverlay()
    }

    private fun destroyOverlay() {
        handler.removeCallbacks(hideRunnable)
        content?.animate()?.cancel()
        try {
            root?.let { wm.removeView(it) }
        } catch (e: Exception) {
            // ignora
        }
        root = null
        content = null
        thinTrack = null
        thinFill = null
        pill = null
        pillFill = null
        params = null
        mode = Mode.HIDDEN
        dragging = false
    }

    // A janela é criada uma vez e fica sempre ali (invisível e sem pegar toque).
    private fun buildOverlay() {
        if (root != null) return

        val edge = if (onRight) Gravity.RIGHT else Gravity.LEFT

        // ----- linha fina -----
        val thinBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = thinW / 2f
            setColor(trackFor(thinColor))
        }
        val thinFillView = View(this).apply {
            setBackgroundColor(thinColor)
            pivotY = barH.toFloat()
            scaleY = 0f
        }
        val thinTrackView = FrameLayout(this).apply {
            background = thinBg
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            addView(
                thinFillView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        // ----- barra grande (estilo iPhone) -----
        val pillBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = pillW * 0.32f
            setColor(pillBgColor)
        }
        val pillFillView = View(this).apply {
            setBackgroundColor(pillFillColor)
            pivotY = barH.toFloat()
            scaleY = 0f
        }
        val iconSize = (pillW * 0.55f).toInt()
        val icon = SpeakerIconView(this)
        icon.iconColor = iconCol
        val pillView = FrameLayout(this).apply {
            background = pillBg
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            addView(
                pillFillView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            addView(
                icon,
                FrameLayout.LayoutParams(
                    iconSize,
                    iconSize,
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                ).apply { bottomMargin = (pillW * 0.22f).toInt() }
            )
            pivotX = if (onRight) pillW.toFloat() else 0f // cresce a partir da borda da tela
            pivotY = barH / 2f
            alpha = 0f
        }

        // ----- conteúdo que desliza pra dentro/fora -----
        val contentView = FrameLayout(this).apply {
            addView(
                thinTrackView,
                FrameLayout.LayoutParams(thinW, barH, Gravity.TOP or edge).apply {
                    if (onRight) rightMargin = marginPx else leftMargin = marginPx
                }
            )
            addView(
                pillView,
                FrameLayout.LayoutParams(pillW, barH, Gravity.TOP or edge).apply {
                    if (onRight) rightMargin = marginPx else leftMargin = marginPx
                }
            )
            alpha = 0f
            translationX = slidePx
        }

        val rootView = FrameLayout(this).apply {
            addView(
                contentView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            setOnTouchListener { _, e -> onOverlayTouch(e) }
        }

        val p = WindowManager.LayoutParams(
            marginPx + thinW + grabPx,
            barH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            idleFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or edge
            x = 0
            y = topY
        }

        try {
            wm.addView(rootView, p)
            root = rootView
            content = contentView
            thinTrack = thinTrackView
            thinFill = thinFillView
            pill = pillView
            pillFill = pillFillView
            params = p
        } catch (e: Exception) {
            // sem permissão de overlay: ignora
        }
    }

    // ================= botões de volume =================

    private fun isHiddenHere(): Boolean = hideApps.contains(foregroundPkg)

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val direction = when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> AudioManager.ADJUST_RAISE
            KeyEvent.KEYCODE_VOLUME_DOWN -> AudioManager.ADJUST_LOWER
            else -> return false
        }

        // barra desligada, ou app escolhido pra esconder: o Android cuida do volume
        if (!enabled || isHiddenHere()) return false

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                // a repetição ao segurar é feita aqui dentro (repeatRunnable)
                if (event.repeatCount == 0) {
                    handler.removeCallbacks(repeatRunnable)
                    heldDirection = direction
                    heldSteps = 0
                    stepVolume(direction)
                    handler.postDelayed(repeatRunnable, repeatStartMs)
                }
            }
            KeyEvent.ACTION_UP -> {
                if (heldDirection == direction) {
                    heldDirection = 0
                    handler.removeCallbacks(repeatRunnable)
                }
            }
        }
        // true = o painel padrão do Android não aparece
        return true
    }

    private fun currentStream(): Int {
        return when (audio.mode) {
            AudioManager.MODE_IN_CALL,
            AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
            else -> AudioManager.STREAM_MUSIC
        }
    }

    private fun stepVolume(direction: Int): Boolean {
        val stream = currentStream()
        val before = audio.getStreamVolume(stream)
        audio.adjustStreamVolume(stream, direction, 0)
        showBar(stream)
        return audio.getStreamVolume(stream) != before
    }

    // ================= mostrar / esconder =================

    private fun showBar(stream: Int) {
        val c = content ?: return
        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        val frac = audio.getStreamVolume(stream).toFloat() / max.toFloat()

        handler.removeCallbacks(hideRunnable)

        if (mode == Mode.HIDDEN) {
            if (variant == Prefs.VARIANT_PILL) {
                preparePill()
                mode = Mode.EXPANDED
            } else {
                prepareThin()
                mode = Mode.THIN
            }
            setFill(frac, false)
        } else {
            setFill(frac, true)
        }

        if (c.translationX != 0f || c.alpha != 1f) {
            c.animate().cancel()
            c.animate()
                .translationX(0f)
                .alpha(1f)
                .setDuration(220)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }

        scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        val delay = if (mode == Mode.EXPANDED && variant == Prefs.VARIANT_BOTH) {
            pillVisibleMs
        } else {
            showMs
        }
        handler.postDelayed(hideRunnable, delay)
    }

    private fun hideBar() {
        handler.removeCallbacks(hideRunnable)
        val c = content ?: return
        if (mode == Mode.HIDDEN) return
        val wasExpanded = mode == Mode.EXPANDED
        mode = Mode.HIDDEN
        dragging = false

        // para de pegar toque na hora
        applyWindow(wasExpanded, false)

        // desliza de volta pra fora da tela, pelo lado em que a barra está
        c.animate().cancel()
        c.animate()
            .translationX(slidePx)
            .alpha(0f)
            .setDuration(220)
            .setInterpolator(AccelerateInterpolator())
            .start()
    }

    private fun prepareThin() {
        thinTrack?.let {
            it.animate().cancel()
            it.alpha = 1f
        }
        pill?.let {
            it.animate().cancel()
            it.alpha = 0f
        }
        applyWindow(false, true)
    }

    private fun preparePill() {
        thinTrack?.let {
            it.animate().cancel()
            it.alpha = 0f
        }
        pill?.let {
            it.animate().cancel()
            it.scaleX = 1f
            it.alpha = 1f
        }
        applyWindow(true, true)
    }

    private fun expand() {
        if (mode != Mode.THIN || variant != Prefs.VARIANT_BOTH) return
        mode = Mode.EXPANDED
        applyWindow(true, true)

        thinTrack?.let {
            it.animate().cancel()
            it.animate().alpha(0f).setDuration(120).start()
        }
        pill?.let {
            it.animate().cancel()
            it.scaleX = 0.6f
            it.animate()
                .alpha(1f)
                .scaleX(1f)
                .setDuration(180)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    // A altura da janela é sempre a mesma; só a largura muda entre linha fina e barra grande.
    private fun applyWindow(expanded: Boolean, touchable: Boolean) {
        val p = params ?: return
        val r = root ?: return
        p.width = if (expanded) marginPx + pillW + dp(2) else marginPx + thinW + grabPx
        p.height = barH
        p.flags = if (touchable) touchFlags else idleFlags
        try {
            wm.updateViewLayout(r, p)
        } catch (e: Exception) {
            // ignora
        }
    }

    private fun setFill(frac: Float, animate: Boolean) {
        for (f in listOfNotNull(thinFill, pillFill)) {
            f.animate().cancel()
            if (animate) {
                f.animate()
                    .scaleY(frac)
                    .setDuration(90)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
            } else {
                f.scaleY = frac
            }
        }
    }

    // ================= toque / arrastar =================

    private fun onOverlayTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            // tocou em qualquer lugar fora da barra: some
            MotionEvent.ACTION_OUTSIDE -> {
                hideBar()
                return true
            }
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacks(hideRunnable)
                downY = e.y
                if (mode == Mode.EXPANDED) beginDrag(e.y) else dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && mode != Mode.HIDDEN && abs(e.y - downY) > touchSlop) {
                    // com as duas versões, vira a barra grande; só com a linha, arrasta nela mesma
                    if (mode == Mode.THIN && variant == Prefs.VARIANT_BOTH) expand()
                    beginDrag(e.y)
                }
                if (dragging) dragTo(e.y)
                return true
            }
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                if (mode != Mode.HIDDEN) scheduleHide()
                return true
            }
        }
        return false
    }

    private fun beginDrag(y: Float) {
        val stream = currentStream()
        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        startFrac = audio.getStreamVolume(stream).toFloat() / max.toFloat()
        startY = y
        dragging = true
    }

    // O volume muda de forma relativa ao movimento do dedo (sem pulos quando você encosta).
    private fun dragTo(y: Float) {
        val stream = currentStream()
        val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
        val frac = (startFrac + (startY - y) / barH).coerceIn(0f, 1f)
        val level = (frac * max).roundToInt()
        if (audio.getStreamVolume(stream) != level) {
            audio.setStreamVolume(stream, level, 0)
        }
        setFill(frac, false)
    }

    // ================= qual app está aberto =================

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: ""

        // ignora a barra de notificações e o teclado: o app de baixo continua sendo o mesmo
        if (pkg == "com.android.systemui" || cls.startsWith("android.inputmethodservice")) return

        if (pkg != foregroundPkg) {
            foregroundPkg = pkg
            if (hideApps.contains(pkg)) {
                heldDirection = 0
                handler.removeCallbacks(repeatRunnable)
                hideBar()
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(repeatRunnable)
        handler.removeCallbacks(applyPrefsRunnable)
        Prefs.of(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        if (::wm.isInitialized) destroyOverlay()
        super.onDestroy()
    }
}
